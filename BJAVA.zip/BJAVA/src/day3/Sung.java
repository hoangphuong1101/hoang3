package day3;

public class Sung extends VuKhi {
	public static String loaiVK = "Vu khi gay sat thuong cao";
	private int soDan;

	public Sung(String tenVuKhi, int satThuong, int soDan) {
		super(tenVuKhi, satThuong);
		this.soDan = soDan;
	}

	/**
	 * @return the soDan
	 */
	public int getSoDan() {
		return soDan;
	}

	/**
	 * @param soDan
	 *            the soDan to set
	 */
	public void setSoDan(int soDan) {
		this.soDan = soDan;
	}

	@Override
	public void gaySatThuong(Nguoi nguoi) {
		nguoi.setHp(nguoi.getHp() - this.getSatThuong());
		System.out.println("Bi sat thuong boi Sung");
	}

}
