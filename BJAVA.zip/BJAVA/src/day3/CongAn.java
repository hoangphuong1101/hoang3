package day3;

public class CongAn extends Nguoi implements ISuDungVuKhi{
	private String capBac; 
	private VuKhi vuKhi;
	
	public CongAn(String ten, int tien, int tuoi, boolean biBat, int hp, boolean conSong, String capBac, VuKhi vuKhi) {
		super(ten, tien, tuoi, hp, conSong);
		this.capBac = capBac;
		this.vuKhi = vuKhi;
	}

	/**
	 * @return the vuKhi
	 */
	public VuKhi getVuKhi() {
		return vuKhi;
	}

	/**
	 * @param vuKhi the vuKhi to set
	 */
	public void setVuKhi(VuKhi vuKhi) {
		this.vuKhi = vuKhi;
	}

	/**
	 * @return the capBac
	 */
	public String getCapBac() {
		return capBac;
	}

	/**
	 * @param capBac the capBac to set
	 */
	public void setCapBac(String capBac) {
		this.capBac = capBac;
	}

	@Override
	public void diLam() {
		System.out.println(this.getClass().getSimpleName()+" Truy bat toi pham");
	}

	@Override
	public void tanCong(Nguoi nguoi) {
		System.out.println("\tHanh dong tan cong va bat giu toi pham :" + nguoi.getTen());
	}
	
	public void batToiPham(Nguoi nguoi){
		if (nguoi instanceof ToiPham) {
			ToiPham tp = (ToiPham) nguoi;
			System.out.println(tp.getTen()+ " -> La toi pham");
			this.tanCong(nguoi);
		}else{
			System.out.println(nguoi.getTen()+" -> Khong phai la toi pham ");
		}
	}
}
