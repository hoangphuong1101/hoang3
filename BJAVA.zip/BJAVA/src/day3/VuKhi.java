package day3;

public abstract class VuKhi {
	private String tenVuKhi;
	private int satThuong;
	
	public VuKhi(String tenVuKhi, int satThuong) {
		super();
		this.tenVuKhi = tenVuKhi;
		this.satThuong = satThuong;
	}

	/**
	 * @return the tenVuKhi
	 */
	public String getTenVuKhi() {
		return tenVuKhi;
	}

	/**
	 * @param tenVuKhi the tenVuKhi to set
	 */
	public void setTenVuKhi(String tenVuKhi) {
		this.tenVuKhi = tenVuKhi;
	}

	/**
	 * @return the satThuong
	 */
	public int getSatThuong() {
		return satThuong;
	}

	/**
	 * @param satThuong the satThuong to set
	 */
	public void setSatThuong(int satThuong) {
		this.satThuong = satThuong;
	}

	public abstract void gaySatThuong(Nguoi nguoi);
}
