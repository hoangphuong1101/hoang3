package day3;

public class Dao extends VuKhi {

	public static String loaiVK = "Vu khi can chien";

	public Dao(String tenVuKhi, int satThuong) {
		super(tenVuKhi, satThuong);
	}

	@Override
	public void gaySatThuong(Nguoi nguoi) {
		nguoi.setHp(nguoi.getHp() - this.getSatThuong());
		System.out.println("Bi sat thuong boi Dao");
	}

}
