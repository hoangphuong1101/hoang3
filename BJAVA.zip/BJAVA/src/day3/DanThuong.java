package day3;

public class DanThuong extends Nguoi {

	public DanThuong(String ten, int tien, int tuoi, boolean biBat, int hp, boolean conSong) {
		super(ten, tien, tuoi, hp, conSong);
	}

	@Override
	public void diLam() {
		System.out.println(this.getClass().getSimpleName()+" Di lam kiem tien");

	}

}
