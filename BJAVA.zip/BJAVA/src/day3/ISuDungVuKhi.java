package day3;

public interface ISuDungVuKhi {
	public void tanCong(Nguoi nguoi);
}
