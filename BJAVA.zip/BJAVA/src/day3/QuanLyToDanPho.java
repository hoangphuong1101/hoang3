package day3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class QuanLyToDanPho {
	ArrayList<Nguoi> listNguoi = new ArrayList<>();
	CongAn congAn = new CongAn("Mory", 0, 30, false, 100, true, "Dai Uy", null);

	public QuanLyToDanPho() {
		Nguoi nguoi;
		VuKhi vk;
		vk = new Sung("AK-47", 52, 30);
		nguoi = new CongAn("Edogawa Conan", 20000, 30, false, 100, true, "Thuong Uy", vk);
		listNguoi.add(nguoi);
		nguoi = new DanThuong("Nguyen Van A", 5000000, 10, false, 100, true);
		listNguoi.add(nguoi);
		vk = new Dao("Katana", 81);
		nguoi = new ToiPham("Kaito Kid", 0, 50, false, 100, false, "Cuop giat tai san", vk);
		listNguoi.add(nguoi);
	}

	void goiTatCaDiLam() {
		for (Nguoi m : listNguoi) {
			m.diLam();
		}
	}

	void batToiPham() {
		for (Nguoi nguoi : listNguoi) {
			congAn.batToiPham(nguoi);
		}
	}

	void sapXepTheoTien() {
		Collections.sort(listNguoi);
		for (Nguoi nguoi : listNguoi) {
			System.out.println(nguoi.getTien());
		}
	}

	public static void main(String[] args) {
		QuanLyToDanPho ql = new QuanLyToDanPho();
		ql.goiTatCaDiLam();
		System.out.println("------------<< Hanh dong cua cong an ten " + ql.congAn.getTen() + " >>--------------");
		ql.batToiPham();

		ql.sapXepTheoTien();

	}
}
