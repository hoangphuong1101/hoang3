package day3;

public class ToiPham extends Nguoi implements ISuDungVuKhi{
	private String toi;
	private VuKhi vuKhi;
	
	public ToiPham(String ten, int tien, int tuoi, boolean biBat, int hp, boolean conSong, String toi, VuKhi vuKhi) {
		super(ten, tien, tuoi, hp, conSong);
		this.toi = toi;
		this.vuKhi = vuKhi;
	}

	/**
	 * @return the vuKhi
	 */
	public VuKhi getVuKhi() {
		return vuKhi;
	}

	/**
	 * @param vuKhi the vuKhi to set
	 */
	public void setVuKhi(VuKhi vuKhi) {
		this.vuKhi = vuKhi;
	}

	/**
	 * @return the toi
	 */
	public String getToi() {
		return toi;
	}

	/**
	 * @param toi
	 *            the toi to set
	 */
	public void setToi(String toi) {
		this.toi = toi;
	}

	@Override
	public void diLam() {
		System.out.println(this.getClass().getSimpleName()+" Di pham toi");

	}

	@Override
	public void tanCong(Nguoi nguoi) {
		System.out.println("Gay sat thuong "+ nguoi.getClass().getSimpleName());
	}
	
	public void tronThoat(){
		this.setBiBat(false);
	}
}
