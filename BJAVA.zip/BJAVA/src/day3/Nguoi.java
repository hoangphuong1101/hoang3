package day3;

import java.util.Comparator;

public abstract class Nguoi implements Comparable<Nguoi> {
	private String ten;
	private int tien;
	private int tuoi;
	private boolean biBat;
	private int hp;
	protected boolean conSong;

	public Nguoi(String ten, int tien, int tuoi, int hp, boolean conSong) {
		this.ten = ten;
		this.tien = tien;
		this.tuoi = tuoi;
		this.hp = hp;
		this.conSong = conSong;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Nguoi obj1) {
		return this.tien - obj1.tien;
	}

	/**
	 * @return the hp
	 */
	public int getHp() {
		return hp;
	}

	/**
	 * @param hp
	 *            the hp to set
	 */
	public void setHp(int hp) {
		this.hp = hp;
	}

	public abstract void diLam();

	/**
	 * @return the ten
	 */
	public String getTen() {
		return ten;
	}

	/**
	 * @param ten
	 *            the ten to set
	 */
	public void setTen(String ten) {
		this.ten = ten;
	}

	/**
	 * @return the tien
	 */
	public int getTien() {
		return tien;
	}

	/**
	 * @param tien
	 *            the tien to set
	 */
	public void setTien(int tien) {
		this.tien = tien;
	}

	/**
	 * @return the tuoi
	 */
	public int getTuoi() {
		return tuoi;
	}

	/**
	 * @param tuoi
	 *            the tuoi to set
	 */
	public void setTuoi(int tuoi) {
		this.tuoi = tuoi;
	}

	/**
	 * @return the biBat
	 */
	public boolean isBiBat() {
		return biBat;
	}

	/**
	 * @param biBat
	 *            the biBat to set
	 */
	public void setBiBat(boolean biBat) {
		this.biBat = biBat;
	}

}
