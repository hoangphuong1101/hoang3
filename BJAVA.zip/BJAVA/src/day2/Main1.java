package day2;

import java.util.ArrayList;
import java.util.Scanner;

public class Main1 extends Candidate {
	
	ArrayList<Candidate> list = new ArrayList<>();

	public void run() {
		while (true) {
			excute();
		}
	}

	public void excute() {
		Candidate c;
		display();
		int n = selected();
		switch (n) {
		case 1:
			c = new ExperienceCandidate();
			c.setCandidateType(0);
			c.nhap();
			list.add(c);
			break;
		case 2:
			c = new FresherCandidate();
			c.setCandidateType(1);
			c.nhap();
			list.add(c);
			break;
		case 3:
			c = new InternCadidate();
			c.setCandidateType(2);
			c.nhap();
			list.add(c);
			break;
		case 4:
			for(Candidate m: list){
				System.out.println(m);
			}
			break;
		default:
			break;
		}
	}
	

	public int selected() {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap mot so :");
		return sc.nextInt();
	}

	public void display() {
		System.out.println("-----<<< CHUONG TRINH >>>------");
		System.out.println("1. Them ung vien ExperienceCandidate");
		System.out.println("2. Them ung vien FresherCandidate ");
		System.out.println("3. Them ung vien InternCandidate");
		System.out.println("4. Xem danh sach");
		System.out.println("---Nhan phim bat ky de thoat---");
	}

	public static void main(String[] args) {
		Main1 a = new Main1();
		a.run();
	}

}
