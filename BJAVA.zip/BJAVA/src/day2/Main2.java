package day2;

import java.util.ArrayList;
import java.util.Scanner;

public class Main2 {
	ArrayList<Candidate> listCandidate = new ArrayList<>();
	ArrayList<Recruitment> listRecruitmentPackage = new ArrayList<>();

	
	public Main2() {
		// add data
		Candidate c;
	}

	public void run() {
		while (true) {
			excute();
		}
	}

	public void excute() {
		Candidate c;
		display();
		int n = selected();
		switch (n) {
		case 1:
			break;
		case 2:

			break;
		case 3:
			break;
		case 4:
			break;
		default:
			break;
		}
	}

	public int selected() {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap mot so :");
		return sc.nextInt();
	}

	public void display() {
		System.out.println("-----<<< CHUONG TRINH >>>------");
		System.out.println("1. Chon goi tuyen dung");
		System.out.println("2. Xem danh sach");
		System.out.println("---Nhan phim bat ky de thoat---");
	}

	public static void main(String[] args) {
		Main1 a = new Main1();
		a.run();
	}
}
