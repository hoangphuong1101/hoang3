package day2;

import java.util.Calendar;
import java.util.Scanner;

public abstract class Candidate {
	private String firstName;
	private String lastName;
	private int birthDate;
	private String address;
	private String phone;
	private String email;
	private int candidateType;

	public Candidate() {
	}

	public Candidate(String firstName, String lastName, int birthDate, String address, String phone, String email,
			int candidateType) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.birthDate = birthDate;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.candidateType = candidateType;
	}

	public void nhap() {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap firstName :");
		this.firstName = sc.nextLine();
		System.out.print("Nhap lastName :");
		this.lastName = sc.nextLine();
		System.out.print("Nhap birthDate :");
		this.birthDate = sc.nextInt();
		int year = Calendar.getInstance().get(Calendar.YEAR);
		while (this.birthDate < 1900 || this.birthDate > year) {
			System.out.print("[Birth date nam ngoai khoang 1900->Current Year ] Nhap lai year :");
			this.birthDate = sc.nextInt();
		}

		sc.nextLine();
		System.out.print("Nhap Address :");
		this.address = sc.nextLine();

		System.out.print("Nhap Phone :");
		this.phone = sc.nextLine();
		PhoneValidator phoneValidator = new PhoneValidator();
		while (true != phoneValidator.validate(this.phone)) {
			System.out.print("[Toi thieu 7 chu so nguyen duong] Nhap lai Phone :");
			this.phone = sc.nextLine();
		}

		EmailValidator ckEmail = new EmailValidator();
		System.out.print("Nhap Email :");
		this.email = sc.nextLine();
		while (ckEmail.validate(this.email) != true) {
			System.out.print("[Sai dinh dang mail] Nhap lai Email :");
			this.email = sc.nextLine();
		}

	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the birthDate
	 */
	public int getBirthDate() {
		return birthDate;
	}

	/**
	 * @param birthDate
	 *            the birthDate to set
	 */
	public void setBirthDate(int birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone
	 *            the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the candidateType
	 */
	public int getCandidateType() {
		return candidateType;
	}

	/**
	 * @param candidateType
	 *            the candidateType to set
	 */
	public void setCandidateType(int candidateType) {
		this.candidateType = candidateType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Candidate [FirstName=" + getFirstName() + ", LastName=" + getLastName() + ", BirthDate="
				+ getBirthDate() + ", Address=" + getAddress() + ", Phone=" + getPhone() + ", Email=" + getEmail()
				+ ", CandidateType=" + getCandidateType() + "]";
	}

}
