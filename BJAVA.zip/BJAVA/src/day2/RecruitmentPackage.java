package day2;

public class RecruitmentPackage {
	private String namePackage;
	private String typeCandidate;
	
	public RecruitmentPackage(String namePackage, String typeCandidate) {
		this.namePackage = namePackage;
		this.typeCandidate = typeCandidate;
	}
	

	/**
	 * @return the namePackage
	 */
	public String getNamePackage() {
		return namePackage;
	}


	/**
	 * @param namePackage the namePackage to set
	 */
	public void setNamePackage(String namePackage) {
		this.namePackage = namePackage;
	}


	/**
	 * @return the typeCandidate
	 */
	public String getTypeCandidate() {
		return typeCandidate;
	}
	/**
	 * @param typeCandidate the typeCandidate to set
	 */
	public void setTypeCandidate(String typeCandidate) {
		this.typeCandidate = typeCandidate;
	}
	
}
