package day2;                                                                                              
                                                                                                                 
import java.util.Scanner;                                                                                        
                                                                                                                 
public class ExperienceCandidate extends Candidate {                                                             
                                                                                                                 
	private int expInYear;                                                                                       
	private String proSkill;                                                                                     
                                                                                                                 
	public ExperienceCandidate() {                                                                               
	}                                                                                                            
                                                                                                                 
	public ExperienceCandidate(int expInYear, String proSkill) {                                                 
		super();                                                                                                 
		this.expInYear = expInYear;                                                                              
		this.proSkill = proSkill;                                                                                
	}                                                                                                            
                                                                                                     
                                                                                                                 
	public ExperienceCandidate(String firstName, String lastName, int birthDate, String address, String phone,
			String email, int expInYear, String proSkill) {
		super(firstName, lastName, birthDate, address, phone, email, 0);
		this.expInYear = expInYear;
		this.proSkill = proSkill;
	}

	@Override                                                                                                    
	public void nhap() {                                                                                         
		super.nhap();                                                                                            
		@SuppressWarnings("resource")                                                                            
		Scanner sc = new Scanner(System.in);       
		System.out.print("Nhap expInYear :");                                                                  
		this.expInYear = sc.nextInt();                       
		do {                                                                                                     
			System.out.print("[0 < expInYear < 100]Nhap lai expInYear :");                                                                  
			this.expInYear = sc.nextInt();                                                                       
		} while (this.expInYear < 0 || this.expInYear > 100);                                                                                                                                            
		System.out.print("Nhap ProSkill :"); 
		sc.next();
		this.proSkill = sc.nextLine();                                                                           
	}                                                                                                            
                                                                                                                 
	/**                                                                                                          
	 * @return the expInYear                                                                                     
	 */                                                                                                          
	public int getExpInYear() {                                                                                  
		return expInYear;                                                                                        
	}                                                                                                            
                                                                                                                 
	/**                                                                                                          
	 * @param expInYear                                                                                          
	 *            the expInYear to set                                                                           
	 */                                                                                                          
	public void setExpInYear(int expInYear) {                                                                    
		this.expInYear = expInYear;                                                                              
	}                                                                                                            
                                                                                                                 
	/**                                                                                                          
	 * @return the proSkill                                                                                      
	 */                                                                                                          
	public String getProSkill() {                                                                                
		return proSkill;                                                                                         
	}                                                                                                            
                                                                                                                 
	/**                                                                                                          
	 * @param proSkill                                                                                           
	 *            the proSkill to set                                                                            
	 */                                                                                                          
	public void setProSkill(String proSkill) {                                                                   
		this.proSkill = proSkill;                                                                                
	}                                                                                                            
                                                                                                                 
	/*                                                                                                           
	 * (non-Javadoc)                                                                                             
	 *                                                                                                           
	 * @see java.lang.Object#toString()                                                                          
	 */                                                                                                          
	@Override                                                                                                    
	public String toString() {                                                                                   
		return "ExperienceCandidate [ExpInYear()=" + getExpInYear() + ", ProSkill()=" + getProSkill()            
				 + super.toString() + "]";                                                                       
	}                                                                                                            
                                                                                                                 
}                                                                                                                
                                                                                                                 