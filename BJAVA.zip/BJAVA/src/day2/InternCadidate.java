package day2;

import java.util.Scanner;

public class InternCadidate extends Candidate {
	private String majors;
	private String semester;
	private String universityName;

	public String getMajors() {
		return majors;
	}

	public InternCadidate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InternCadidate(String firstName, String lastName, int birthDate, String address, String phone, String email,
			String majors, String semester, String universityName) {
		super(firstName, lastName, birthDate, address, phone, email, 2);
		this.majors = majors;
		this.semester = semester;
		this.universityName = universityName;
	}

	@Override
	public void nhap() {
		super.nhap();
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap Majors :");
		this.majors = sc.nextLine();
		System.out.print("Nhap Semester :");
		this.semester = sc.nextLine();
		System.out.print("Nhap UniversityName :");
		this.universityName = sc.nextLine();
	}

	/**
	 * @return the semester
	 */
	public String getSemester() {
		return semester;
	}

	/**
	 * @param semester
	 *            the semester to set
	 */
	public void setSemester(String semester) {
		this.semester = semester;
	}

	/**
	 * @return the universityName
	 */
	public String getUniversityName() {
		return universityName;
	}

	/**
	 * @param universityName
	 *            the universityName to set
	 */
	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}

	/**
	 * @param majors
	 *            the majors to set
	 */
	public void setMajors(String majors) {
		this.majors = majors;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InternCadidate [Majors=" + getMajors() + ", Semester=" + getSemester() + ", UniversityName="
				+ getUniversityName() + super.toString() + "]";
	}

}
