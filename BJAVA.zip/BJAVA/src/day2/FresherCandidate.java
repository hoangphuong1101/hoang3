package day2;

import java.util.Scanner;

public class FresherCandidate extends Candidate {
	private String graduationDate;
	private String graduationRank;
	private String education;

	public FresherCandidate() {
	}

	public FresherCandidate(String firstName, String lastName, int birthDate, String address, String phone,
			String email, String graduationDate, String graduationRank, String education) {
		super(firstName, lastName, birthDate, address, phone, email, 1);
		this.graduationDate = graduationDate;
		this.graduationRank = graduationRank;
		this.education = education;
	}

	@Override
	public void nhap() {
		super.nhap();
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap graduationDate :");
		this.graduationDate = sc.nextLine();
		System.out.println("Chon graduationRank");
		System.out.println("1.Excellence");
		System.out.println("2.Good");
		System.out.println("3.Fair");
		System.out.println("4.Poor");
		System.out.print("Nhap mot so: ");
		int n = sc.nextInt();
		switch (n) {
		case 1:
			this.graduationRank = "Excellence";
			break;
		case 2:
			this.graduationRank = "Good";
			break;
		case 3:
			this.graduationRank = "Fair";
			break;
		case 4:
			this.graduationRank = "Poor";
			break;
		}
		System.out.print("Nhap UniversityName");
		this.education = sc.nextLine();

	}

	/**
	 * @return the graduationDate
	 */
	public String getGraduationDate() {
		return graduationDate;
	}

	/**
	 * @param graduationDate
	 *            the graduationDate to set
	 */
	public void setGraduationDate(String graduationDate) {
		this.graduationDate = graduationDate;
	}

	/**
	 * @return the graduationRank
	 */
	public String getGraduationRank() {
		return graduationRank;
	}

	/**
	 * @param graduationRank
	 *            the graduationRank to set
	 */
	public void setGraduationRank(String graduationRank) {
		this.graduationRank = graduationRank;
	}

	/**
	 * @return the education
	 */
	public String getEducation() {
		return education;
	}

	/**
	 * @param education
	 *            the education to set
	 */
	public void setEducation(String education) {
		this.education = education;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FresherCandidate [getGraduationDate()=" + getGraduationDate() + ", getGraduationRank()="
				+ getGraduationRank() + ", getEducation()=" + getEducation() + super.toString() + "]";
	}

}
