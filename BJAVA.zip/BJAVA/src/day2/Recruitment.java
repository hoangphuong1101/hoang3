package day2;

import java.util.ArrayList;

public class Recruitment {
	private int recruitmentID;
	private String type;
	private	RecruitmentPackage recruitmentpackage;
	private ArrayList<Candidate> listCandidate = new ArrayList<>();
	
	public Recruitment(int recruitmentID, String type, RecruitmentPackage recruitmentpackage) {
		this.recruitmentID = recruitmentID;
		this.type = type;
		this.recruitmentpackage = recruitmentpackage;
	}
	/**
	 * @return the recruitmentID
	 */
	public int getRecruitmentID() {
		return recruitmentID;
	}
	/**
	 * @return the listCandidate
	 */
	public ArrayList<Candidate> getListCandidate() {
		return listCandidate;
	}
	/**
	 * @param listCandidate the listCandidate to set
	 */
	public void setListCandidate(ArrayList<Candidate> listCandidate) {
		this.listCandidate = listCandidate;
	}
	/**
	 * @param recruitmentID the recruitmentID to set
	 */
	public void setRecruitmentID(int recruitmentID) {
		this.recruitmentID = recruitmentID;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the recruitmentpackage
	 */
	public RecruitmentPackage getRecruitmentpackage() {
		return recruitmentpackage;
	}
	/**
	 * @param recruitmentpackage the recruitmentpackage to set
	 */
	public void setRecruitmentpackage(RecruitmentPackage recruitmentpackage) {
		this.recruitmentpackage = recruitmentpackage;
	}

	
	
}
