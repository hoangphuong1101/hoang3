package javabasicfinal;

public class Application {
	public static void main(String[] args) {
		DataAccess.createTable(null);
	}
}
