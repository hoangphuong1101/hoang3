package javabasicfinal;

public class Nguoi {
	private String ten;
	private String tuoi;
	private String ngaySinh;

	/**
	 * @return the ten
	 */
	public String getTen() {
		return ten;
	}

	/**
	 * @param ten
	 *            the ten to set
	 */
	public void setTen(String ten) {
		this.ten = ten;
	}

	/**
	 * @return the tuoi
	 */
	public String getTuoi() {
		return tuoi;
	}

	/**
	 * @param tuoi
	 *            the tuoi to set
	 */
	public void setTuoi(String tuoi) {
		this.tuoi = tuoi;
	}

	/**
	 * @return the ngaySinh
	 */
	public String getNgaySinh() {
		return ngaySinh;
	}

	/**
	 * @param ngaySinh
	 *            the ngaySinh to set
	 */
	public void setNgaySinh(String ngaySinh) {
		this.ngaySinh = ngaySinh;
	}

}
