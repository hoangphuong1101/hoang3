package javabasicfinal;

public class Validator {
}
