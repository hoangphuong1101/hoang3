package javabasicfinal;
import java.lang.reflect.Constructor;
import java.lang.reflect.Parameter;

public class Hibernate {
	public void getImfoConstructor(Object obj) {
		Constructor[] constructors = obj.getClass().getConstructors();
		for (Constructor constructor : constructors) {
			System.out.println(constructor.getParameterCount());
			if(constructor.getParameterCount() > 0) {
				for (Parameter m : constructor.getParameters()) {
					System.out.println("Type name :"+m.getName()+"- "+m.getType().getSimpleName());
				}
				
			}
		    
		}
	}
}
