package day2_2;

public abstract class ThreeDimensionalShape extends Shape{
	public static final double PI = 3.14;
	
	public abstract void getVolume(); 
}
