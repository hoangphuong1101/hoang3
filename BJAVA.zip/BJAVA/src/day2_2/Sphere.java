package day2_2;

public class Sphere extends ThreeDimensionalShape {
	private int r;

	public Sphere(int r) {
		this.r = r;
	}

	/**
	 * @return the r
	 */
	public int getR() {
		return r;
	}

	/**
	 * @param r the r to set
	 */
	public void setR(int r) {
		this.r = r;
	}

	@Override
	public void getArea() {
		System.out.println("Sphere Area :" + (4 * PI * r * r));
	}

	@Override
	public void getVolume() {
		System.out.println("Sphere Volume :" + (4 / 3 * PI) * r * r * r);

	}

}
