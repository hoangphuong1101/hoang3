package day2_2;

public class Tetrahedron extends ThreeDimensionalShape {
	private int a;

	public Tetrahedron(int a) {
		this.a = a;
	}

	/**
	 * @return the a
	 */
	public int getA() {
		return a;
	}

	/**
	 * @param a
	 *            the a to set
	 */
	public void setA(int a) {
		this.a = a;
	}

	@Override
	public void getArea() {
		System.out.println("Tetrahedron Area :" + 1.0 / 4 * Math.sqrt(3) * a * a);
	}

	@Override
	public void getVolume() {
		System.out.println("Tetrahedron Volume :" + Math.sqrt(3) * a * a);
	}

}
