package day2_2;

public class Cube extends ThreeDimensionalShape {
	private int a;

	public Cube(int a) {
		this.a = a;
	}

	/**
	 * @return the a
	 */
	public int getA() {
		return a;
	}

	/**
	 * @param a
	 *            the a to set
	 */
	public void setA(int a) {
		this.a = a;
	}

	@Override
	public void getArea() {
		System.out.println("Cube Area :" + 6 * Math.pow(a, 2));
	}

	@Override
	public void getVolume() {
		System.out.println("Cube Volume :" + Math.pow(a, 3));
	}

}
