package day2_2;

public abstract class TwoDimensionalShape extends Shape{
}
