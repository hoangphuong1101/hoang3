package day2_2;

public abstract class Shape {
	public abstract void getArea();
}
