package day2_2;

public class Square extends TwoDimensionalShape {
	private int side;

	public Square(int side) {
		this.side = side;
	}

	@Override
	public void getArea() {
		System.out.println("Square Area :" + Math.pow(side, 4));
	}

	/**
	 * @return the side
	 */
	public int getSide() {
		return side;
	}

	/**
	 * @param side the side to set
	 */
	public void setSide(int side) {
		this.side = side;
	}
}
