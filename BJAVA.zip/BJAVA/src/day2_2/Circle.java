package day2_2;

public class Circle extends TwoDimensionalShape {
	private int r;

	public Circle(int r) {
		this.r = r;
	}

	/**
	 * @return the r
	 */
	public int getR() {
		return r;
	}

	/**
	 * @param r
	 *            the r to set
	 */
	public void setR(int r) {
		this.r = r;
	}

	@Override
	public void getArea() {
		System.out.println("Circle Area :" + (3.14 * Math.pow(r, 2)));
	}

}
