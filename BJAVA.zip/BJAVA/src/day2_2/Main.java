package day2_2;

import java.util.ArrayList;

public class Main {
	private ArrayList<Shape> shapes = new ArrayList<>();

	public Main() {
		Shape s;
		s = new Circle(10);
		shapes.add(s);
		s = new Cube(10);
		shapes.add(s);
		s = new Sphere(10);
		shapes.add(s);
		s = new Square(10);
		shapes.add(s);
		s = new Tetrahedron(10);
		shapes.add(s);
		s = new Triangle(6, 8, 10);
		shapes.add(s);
	}

	/**
	 * @return the shapes
	 */
	public ArrayList<Shape> getShapes() {
		return shapes;
	}

	/**
	 * @param shapes
	 *            the shapes to set
	 */
	public void setShapes(ArrayList<Shape> shapes) {
		this.shapes = shapes;
	}

	public static void main(String[] args) {
		Main m1 = new Main();
		
		for (Shape m : m1.getShapes()) {
			System.out.println("---<<<< "+m.getClass().getSimpleName()+" >>>>---");
			if (m instanceof TwoDimensionalShape) {
				TwoDimensionalShape tmp = (TwoDimensionalShape) m;
				tmp.getArea();
			} else if (m instanceof ThreeDimensionalShape) {
				ThreeDimensionalShape tmp = (ThreeDimensionalShape) m;
				tmp.getArea();
				tmp.getVolume();
			}
		}

	}
}
