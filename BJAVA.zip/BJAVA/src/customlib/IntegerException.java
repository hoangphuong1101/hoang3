package customlib;

public class IntegerException extends Exception {
	public static boolean validate(String s) {
		try {
			Integer.parseInt(s);
		} catch (NumberFormatException e) {
			return false;
		} catch (NullPointerException e) {
			return false;
		}
		
		return true;
	}
}
