package customlib;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class DateException extends Exception{

	private static final String DATE_PATTERN = "dd-MM-yyyy";

	public DateException() {
	}

	/**
	 * Validate hex with regular expression
	 *
	 * @param hex
	 *            hex for validation
	 * @return true valid hex, false invalid hex
	 */
	public boolean validate(String hex) {
		return false;

	}
	
	public static boolean isDateValid(String date) 
	{
	        try {
	            DateFormat df = new SimpleDateFormat(DATE_PATTERN);
	            df.setLenient(false);
	            df.parse(date);
	            return true;
	        } catch (ParseException e) {
	            return false;
	        }
	}
	

}
