package customlib;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class FileProccessing {
	private String fInput;
	private String fOutput;
	protected ArrayList<String> result = new ArrayList<>();

	public FileProccessing() {
		fInput = "D:\\File\\input.txt";
		fOutput = "D:\\File\\output.txt";
	}
	
	public ArrayList<String> readFile() {
		 ArrayList<String> arr = new ArrayList<>();

		BufferedReader br = null;
		FileReader fr = null;
		try {
			fr = new FileReader(fInput);
			br = new BufferedReader(fr);
			String sCurrentLine;
			br = new BufferedReader(new FileReader(fInput));
			while ((sCurrentLine = br.readLine()) != null) {
				System.out.println(sCurrentLine);
				arr.add(sCurrentLine);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
				if (fr != null)
					fr.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		
		return arr;
	}

	public void writeFile(String content) {
		BufferedWriter bw = null;
		FileWriter fw = null;

		try {
			fw = new FileWriter(fOutput);
			bw = new BufferedWriter(fw);
			bw.write(content);
			System.out.println("WriteFile Done");

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {

				ex.printStackTrace();
			}
		}
	}
	
	public void writeFile(ArrayList<Object> content) {
		BufferedWriter bw = null;
		FileWriter fw = null;

		try {
			fw = new FileWriter(fOutput);
			bw = new BufferedWriter(fw);
			
			for (Object m : content) {
				bw.write(String.valueOf(m));
				bw.newLine();
			}
			
			System.out.println("WriteFile Done");

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {

				ex.printStackTrace();
			}
		}
	}

	/**
	 * @return the fInput
	 */
	public String getfInput() {
		return fInput;
	}

	/**
	 * @param fInput
	 *            the fInput to set
	 */
	public void setfInput(String fInput) {
		this.fInput = fInput;
	}

	/**
	 * @return the fOutput
	 */
	public String getfOutput() {
		return fOutput;
	}

	/**
	 * @param fOutput
	 *            the fOutput to set
	 */
	public void setfOutput(String fOutput) {
		this.fOutput = fOutput;
	}

	
	public static void main(String[] args) {
		FileProccessing fp = new FileProccessing();
//		fp.setfInput("D:\\File\\input.txt");
//		fp.setfOutput("D:\\File\\output.txt");
//		fp.readFile();
//		fp.writeFile(fp.readFile());
//		testEx();
	}
}
