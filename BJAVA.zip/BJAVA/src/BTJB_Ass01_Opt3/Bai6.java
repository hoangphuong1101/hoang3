package BTJB_Ass01_Opt3;

public class Bai6 {
	public static int bai6(int n) {
		int i = 0, tmp = 1;

		i = n % 2 != 0 ? 1 : 2;

		for (; i <= n; i += 2) {
			tmp *= i;
		}
		return tmp;
	}

	public static void main(String[] args) {
		System.out.println(bai6(10));
	}
}
