package BTJB_Ass01_Opt3;

import java.util.Vector;

public class MyStack {
	private int stackValues;
	private Vector<Object> containValues = new Vector<>();;
	
	public void push(int num){
		stackValues++;
		containValues.add(num);
	}
	
	public void pop(){
		if(stackValues == 0){
			System.out.println("Stack empty !");
		}else{
			containValues.removeElementAt(stackValues-1);
			stackValues--;
		}
	}
	
	public void get(){
		System.out.println("Stack values :"+stackValues);
	}
	
	public void display(){
		System.out.println(containValues);
	}
	
	public static void main(String[] args) {
		MyStack myStack = new MyStack();
		myStack.display();
		myStack.get();
		myStack.push(10);
		myStack.push(20);
		myStack.display();
		myStack.get();
		myStack.pop();
		myStack.display();
		myStack.get();
	}
}
