package BTJB_Ass01_Opt3;

public class Bai2 {
	public static void bai2(int month, int year) {
		if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
			System.out.println("31 days");
		} else if (month == 4 || month == 6 || month == 11) {
			System.out.println("30 days");
		} else if (year % 4 == 0 && year % 100 == 0 || year % 400 == 0) {
			System.out.println("29 days");
		} else
			System.out.println("28 days");
	}

	public static void main(String[] args) {
		bai2(2,2001);
	}

}
