package BTJB_Ass01_Opt3;

import java.util.Scanner;

public class Bai11 {
	public static final Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("------------- A ----------------");
		System.out.print("Nhap n :");
		int n = sc.nextInt();
		int arr[] = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.print("\t--> Nhap phan tu thu A[" + (i + 1) + "] :");
			arr[i] = sc.nextInt();
		}

		System.out.println("------------Nhap xong mang------------");
		System.out.print("Mang :");
		for (int i = 0; i < n; i++) {
			if(i == n -1)
				System.out.print(arr[i]);
			else
				System.out.print(arr[i]+",");
		}
		System.out.println("\n------------- B ----------------");
		int count = 0;
		for (int i = 0; i < n; i++) {
			if (arr[i] % 2 != 0) {
				count++;
			}
		}

		System.out.println("-->Tong so le xuat hien :" + count);
		System.out.println("------------- C ----------------");
		System.out.print("Nhap phan tu k :");
		int k = sc. nextInt();
		boolean check = false;
		int positionK = 0;
		
		for (int i = 0; i < n; i++) {
			if(arr[i] == k){
				positionK = i;
				check = true;
				break;
			}
		}
		
		if(check == true){
			System.out.println("--> Mang co phan tu K va xuat hien tai vi tri : A["+positionK+"]");
		}else{
			System.out.println("--> Phan tu K khong ton tai");
		}
		
		System.out.println("------------- D ----------------");
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n-1; j++){
				if(arr[j] > arr[j+1]){
					int tmp = arr[j+1];
					arr[j+1] = arr[j];
					arr[j] = tmp;
				}
			}
		}
		System.out.print("---> Ket qua mang da sap xep :");
		for (int i = 0; i < n; i++) {
			if(i == n -1)
				System.out.print(arr[i]);
			else
				System.out.print(arr[i]+",");
		}
		
		System.out.println("\n------------- E ----------------");
		System.out.print("Nhap phan tu P: ");
		int p = sc.nextInt();
		int[] arr1 = new int[n+1];
		int positionP = 0;
		
		for(int i = 0; i < n; i++) {
			if(p < arr[i]){
				positionP = i;
				break;
			}
		}
		for(int i = 0; i < n; i++){
			if(positionP > i){
				arr1[i] = arr[i];
			}else
				if(positionP == i){
					arr1[i] = p;
				}else{
					arr1[i+1] = arr[i];
				}
		}
		
		arr1[n] = arr[n-1];
		
		System.out.print("---> Ket qua chen phan tu p :");
		for (int i = 0; i < n+1; i++) {
			if(i == n)
				System.out.print(arr1[i]);
			else
				System.out.print(arr1[i]+",");
		}
		
		
	}
}
