package BTJB_Ass01_Opt3;

public class Bai7 {
	public static void bai7(int m) {
		int P = 1;
		int S = 0;

		while (m != 0) {
			S += m % 10;
			P *= m % 10;
			m /= 10;
		}

		System.out.println("Tong:" + S);
		System.out.println("Tich:" + P);

	}

	public static void main(String[] args) {
		bai7(10);
	}
}
