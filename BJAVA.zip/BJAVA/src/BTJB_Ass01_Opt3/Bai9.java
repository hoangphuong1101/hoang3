package BTJB_Ass01_Opt3;

import java.util.Scanner;

public class Bai9 {
	public static final Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.print("Nhap chuoi: ");
		String str = sc.nextLine();
		System.out.println("--------------------- A -----------------");

		String strRS = "";
		int len = str.length();
		for (int i = len - 1; i >= 0; i--) {
			strRS += str.charAt(i);
		}

		System.out.println("-- KQ A:" + strRS);

		System.out.println("--------------------- B -----------------");
		System.out.println("-- KQ B:" + str.toUpperCase());
		System.out.println("--------------------- C -----------------");
		System.out.println("-- KQ C:" + str.toLowerCase());
		System.out.println("--------------------- D -----------------");

		strRS = "";

		for (int i = 0; i < len; i++) {
			int tmp = str.charAt(i);
			if (tmp >= 97 && tmp <= 122) {
				tmp -= 32;
				strRS += (char) tmp;
			} else if (tmp >= 65 && tmp <= 90) {
				tmp += 32;
				strRS += (char) tmp;
			}

		}
		System.out.println("-- KQ D:" + strRS);
	}
}
