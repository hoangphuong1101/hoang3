package BTJB_Ass01_Opt3;

public class Bai1 {
	public static void bai1(int n) {
		StringBuilder star = new StringBuilder();

		for (int i = 1; i <= n; i++) {
			star.append("*");
			System.out.println(star);
		}
	}

	public static void main(String[] args) {
		bai1(10);
	}
}
