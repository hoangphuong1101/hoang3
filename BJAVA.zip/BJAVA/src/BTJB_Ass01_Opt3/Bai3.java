package BTJB_Ass01_Opt3;

public class Bai3 {
	public static double bai3(int n) {
		double rs = 0;

		for (int i = 1; i <= n; i++) {
			rs += 1.0 / n;
		}

		return rs;
	}
	public static void main(String[] args) {
		System.out.println(bai3(10));
		int a = 'z';
		System.out.println(a);
	}
}
