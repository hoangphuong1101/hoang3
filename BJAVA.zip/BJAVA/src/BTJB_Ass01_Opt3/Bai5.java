package BTJB_Ass01_Opt3;

public class Bai5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
