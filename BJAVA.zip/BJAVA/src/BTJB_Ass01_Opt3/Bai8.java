package BTJB_Ass01_Opt3;

public class Bai8 {
	public static void bai8(int a, int b) {
		int tmp1 = a;
		int tmp2 = b;

		while (tmp1 != tmp2) {
			if (tmp1 > tmp2) {
				tmp1 -= tmp2;
			} else {
				tmp2 -= tmp1;
			}
		}
		System.out.println("UCLN: " + tmp1);
		System.out.println("BCNN: " + (a * b) / tmp1);
	}

	public static void main(String[] args) {
		bai8(10,13);
	}
}
