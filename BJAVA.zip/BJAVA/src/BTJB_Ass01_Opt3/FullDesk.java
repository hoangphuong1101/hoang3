package BTJB_Ass01_Opt3;

import java.util.Scanner;
import java.util.Vector;

public class FullDesk {
	public static final Scanner sc = new Scanner(System.in);
	private Vector<Card> desk = new Vector<>();
	private int deskValue;

	public FullDesk() {
		for (int i = 1; i <= 13; i++) {
			desk.add(new Card(i, "Spades"));
			desk.add(new Card(i, "Clubs"));
			desk.add(new Card(i, "Diamonds"));
			desk.add(new Card(i, "Hearts"));
		}
		this.deskValue = 52;
	}

	public void draw() {
		deskValue--;
		int tmp = (int) (Math.random() * deskValue);
		System.out.println("Card :" + desk.get(tmp));
		desk.remove(tmp);
	}

	public void reset() {
		desk.removeAllElements();
		
		for (int i = 1; i <= 13; i++) {
			desk.add(new Card(i, "Spades"));
			desk.add(new Card(i, "Clubs"));
			desk.add(new Card(i, "Diamonds"));
			desk.add(new Card(i, "Hearts"));
		}
		this.deskValue = 52;
	}

	public void input() {
		display();
		System.out.print("+ Enter a number:");
		int n = sc.nextInt();
		switch (n) {
		case 1:
			this.draw();
			break;
		case 2:
			this.showDesk();
			break;
		case 3:
			this.reset();
			break;
		}
	}

	public void run() {
		while (true) {
			input();
		}
	}

	public void showDesk() {
		System.out.println("---<<< SHOW DESK >>> --");
		if (desk.size() == 0) {
			System.out.println("DESK EMPTY");
		}
		{
			for (int i = 0; i < desk.size(); i++) {
				if (i % 5 == 0) {
					System.out.println("");
				}

				System.out.print(desk.get(i) + "\t\t");
			}
			System.out.println("\n-->>>>>>>DeskValues = " + this.deskValue + "<<<<<<<<<---");
		}
	}

	public void display() {
		System.out.println("---<<<<  Playing cards  >>>>---");
		System.out.println("1. Draw a card");
		System.out.println("2. Display desk of cards");
		System.out.println("3. Reset desk");
	}

	public static void main(String[] args) {
		FullDesk fullDesk = new FullDesk();
		fullDesk.run();
	}

}
