package BTJB_Ass01_Opt3;

public class Bai4 {
	public static double bai4(int n) {
		double tmp = 15;
		int f = 1;

		for (int i = 1; i <= n; i++) {
			f *= i;
			tmp += Math.pow(-1.0, i) / f;
		}

		return tmp;
	}

	public static void main(String[] args) {
		System.out.println(bai4(2));
	}
}
