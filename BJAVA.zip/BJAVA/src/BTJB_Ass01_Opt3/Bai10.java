package BTJB_Ass01_Opt3;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Scanner;

public class Bai10 {
	public static final Scanner sc = new Scanner(System.in);

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		System.out.print("Nhap chuoi: ");
		String tmp = sc.nextLine();

		System.out.println("---------- A ----------");
		for (int i = 0; i < tmp.length(); i++) {
			System.out.println(tmp.charAt(i));
		}
		System.out.println("---------- B ----------");
		System.out.println("So tu: " + tmp.length());
		System.out.println("---------- C ----------");

		@SuppressWarnings("rawtypes")
		Hashtable table = new Hashtable();
		@SuppressWarnings("rawtypes")
		Enumeration numer;
		String str;

		String[] words = tmp.split(" ");
		
		for (int i = 0; i < words.length; i++) {
			str = words[i];
			if (table.containsKey(str)) {
				int count = ((int) table.get(str));
				table.put(str, count + 1);
			} else
				table.put(str, 1);
		}
		// Hien thi hash table.
		numer = table.keys();
		while (numer.hasMoreElements()) {
			str = (String) numer.nextElement();
			System.out.println(str + ": " + table.get(str));

		}

	}
}
