
public class test {
	public int a(String s){
		int n = 0;
		String[] arr = s.split(" ");
		
		for (int i = 1; i < arr.length - 1; i++) {
			if("of".equals(arr[i-1]) && "Items".equals(arr[i+1])){
				try {
					n = Integer.parseInt(arr[i]);
				} catch (NumberFormatException e) {
					continue;
				} 
			}
		}
		
		return n;
	}
	
	public static void main(String[] args) {
		String str = "Display 10000 of 10000 Items";
		test t = new test();
		System.out.println(t.a(str));
	}
}
