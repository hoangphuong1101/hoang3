package day5;

public class BaoHiemTuVong extends GoiBaoHiem {
	public static final int TYPE = 1;  
	private String truongHopDong;
	private String thoiGianToiThieu;

	
	public BaoHiemTuVong() {
		super();
	}

	public BaoHiemTuVong(String thoiHanDong, int mucPhiDong, String mucDich,
			String cachThucDong, String thoiGianBatDau, String truongHopDong, String thoiGianToiThieu) {
		super(thoiHanDong, mucPhiDong, mucDich, cachThucDong, thoiGianBatDau);
		this.setTenGoi(this.getClass().getSimpleName());
		this.truongHopDong = truongHopDong;
		this.thoiGianToiThieu = thoiGianToiThieu;
	}
	
	@Override
	public void nhap() {
		System.out.println("---------[Bao Hiem Tu Vong]-------");
		super.nhap();
		System.out.print("\t+ Nhap truong hop hop dong: ");
		this.truongHopDong = sc.nextLine();
		System.out.print("\t+ Nhap thoi gian toi thieu: ");
		this.thoiGianToiThieu = sc.nextLine();
	}
	
	/**
	 * @return the truongHopDong
	 */
	public String getTruongHopDong() {
		return truongHopDong;
	}

	/**
	 * @param truongHopDong
	 *            the truongHopDong to set
	 */
	public void setTruongHopDong(String truongHopDong) {
		this.truongHopDong = truongHopDong;
	}

	/**
	 * @return the thoiGianToiThieu
	 */
	public String getThoiGianToiThieu() {
		return thoiGianToiThieu;
	}

	/**
	 * @param thoiGianToiThieu
	 *            the thoiGianToiThieu to set
	 */
	public void setThoiGianToiThieu(String thoiGianToiThieu) {
		this.thoiGianToiThieu = thoiGianToiThieu;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return super.toString() + 
			  "\nTruong Hop Dong: " + truongHopDong + 
			  "\nThoi Gian Toi Thieu: " + thoiGianToiThieu;
	}

}
