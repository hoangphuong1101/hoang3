package day5;

public class BaoHiem extends GoiBaoHiem{

}
