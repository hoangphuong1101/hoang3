package day5;

public class BaoHiemSinhKy extends GoiBaoHiem {
	public static final int TYPE = 2;
	private String thoiGianKetThuc;
	private String thoiGianTroCap;

	public BaoHiemSinhKy() {
		super();
	}

	public BaoHiemSinhKy(String thoiHanDong, int mucPhiDong, String mucDich, String cachThucDong, String thoiGianBatDau,
			String thoiGianKetThuc, String thoiGianTroCap) {
		super(thoiHanDong, mucPhiDong, mucDich, cachThucDong, thoiGianBatDau);
		this.setTenGoi(this.getClass().getSimpleName());
		this.thoiGianKetThuc = thoiGianKetThuc;
		this.thoiGianTroCap = thoiGianTroCap;
	}

	@Override
	public void nhap() {
		System.out.println("---------[Bao Hiem Sinh Ky]-------");
		super.nhap();
		System.out.print("\t+ Nhap thoi gian ket thuc");
		this.thoiGianKetThuc = sc.nextLine();
		System.out.print("\t+ Nhap thoi gian tro cap");
		this.thoiGianTroCap = sc.nextLine();
	}

	/**
	 * @return the thoiGianKetThuc
	 */
	public String getThoiGianKetThuc() {
		return thoiGianKetThuc;
	}

	/**
	 * @param thoiGianKetThuc
	 *            the thoiGianKetThuc to set
	 */
	public void setThoiGianKetThuc(String thoiGianKetThuc) {
		this.thoiGianKetThuc = thoiGianKetThuc;
	}

	/**
	 * @return the thoiGianTroCap
	 */
	public String getThoiGianTroCap() {
		return thoiGianTroCap;
	}

	/**
	 * @param thoiGianTroCap
	 *            the thoiGianTroCap to set
	 */
	public void setThoiGianTroCap(String thoiGianTroCap) {
		this.thoiGianTroCap = thoiGianTroCap;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return super.toString() + 
				"\nThoi Gian Ket Thuc: " + thoiGianKetThuc + 
				"\nThoi Gian Tro Cap: " + thoiGianTroCap;
	}

}
