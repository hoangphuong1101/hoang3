package day5;

public class BaoHiemHopDong extends GoiBaoHiem {
	public static final int TYPE = 3;
	private String thoiGianKetThuc;
	private String benhHiemNgheo;
	private String troCapNamVien;
	private String baoHiemThuongTatVV;

	public BaoHiemHopDong() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BaoHiemHopDong(String thoiGianKetThuc, String benhHiemNgheo, String troCapNamVien,
			String baoHiemThuongTatVV) {
		super();
		this.thoiGianKetThuc = thoiGianKetThuc;
		this.benhHiemNgheo = benhHiemNgheo;
		this.troCapNamVien = troCapNamVien;
		this.baoHiemThuongTatVV = baoHiemThuongTatVV;
	}

	public BaoHiemHopDong(String thoiHanDong, int mucPhiDong, String mucDich, String cachThucDong,
			String thoiGianBatDau, String thoiGianKetThuc, String benhHiemNgheo, String troCapNamVien,
			String baoHiemThuongTatVV) {
		super(thoiHanDong, mucPhiDong, mucDich, cachThucDong, thoiGianBatDau);
		this.setTenGoi(this.getClass().getSimpleName());
		this.thoiGianKetThuc = thoiGianKetThuc;
		this.benhHiemNgheo = benhHiemNgheo;
		this.troCapNamVien = troCapNamVien;
		this.baoHiemThuongTatVV = baoHiemThuongTatVV;
	}

	@Override
	public void nhap() {
		System.out.println("---------[Bao hiem hop dong]-------");
		super.nhap();
		System.out.print("\t+ Nhap thoi gian ket thuc");
		this.thoiGianKetThuc = sc.nextLine();
		System.out.print("\t+ Nhap benh hiem ngheo");
		this.benhHiemNgheo = sc.nextLine();
		System.out.print("\t+ Nhap tro cap nam vien");
		this.troCapNamVien = sc.nextLine();
	}

	/**
	 * @return the thoiGianKetThuc
	 */
	public String getThoiGianKetThuc() {
		return thoiGianKetThuc;
	}

	/**
	 * @param thoiGianKetThuc
	 *            the thoiGianKetThuc to set
	 */
	public void setThoiGianKetThuc(String thoiGianKetThuc) {
		this.thoiGianKetThuc = thoiGianKetThuc;
	}

	/**
	 * @return the benhHiemNgheo
	 */
	public String getBenhHiemNgheo() {
		return benhHiemNgheo;
	}

	/**
	 * @param benhHiemNgheo
	 *            the benhHiemNgheo to set
	 */
	public void setBenhHiemNgheo(String benhHiemNgheo) {
		this.benhHiemNgheo = benhHiemNgheo;
	}

	/**
	 * @return the troCapNamVien
	 */
	public String getTroCapNamVien() {
		return troCapNamVien;
	}

	/**
	 * @param troCapNamVien
	 *            the troCapNamVien to set
	 */
	public void setTroCapNamVien(String troCapNamVien) {
		this.troCapNamVien = troCapNamVien;
	}

	/**
	 * @return the baoHiemThuongTatVV
	 */
	public String getBaoHiemThuongTatVV() {
		return baoHiemThuongTatVV;
	}

	/**
	 * @param baoHiemThuongTatVV
	 *            the baoHiemThuongTatVV to set
	 */
	public void setBaoHiemThuongTatVV(String baoHiemThuongTatVV) {
		this.baoHiemThuongTatVV = baoHiemThuongTatVV;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return  super.toString() +
				"\nBao Hiem Hop Dong: " + thoiGianKetThuc + 
				"\nBenh Hiem Ngheo: " + benhHiemNgheo + 
				"\nTro Cap Nam Vien: " + troCapNamVien + 
				"\nBao Hiem Thuong Tat Vinh Vien: " + baoHiemThuongTatVV;
	}

}
