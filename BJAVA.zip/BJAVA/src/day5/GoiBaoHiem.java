package day5;

import java.util.Scanner;

import customlib.IntegerException;

public abstract class GoiBaoHiem {
	public static final Scanner sc = new Scanner(System.in);
	private int maBH;
	private String tenGoi;
	private String thoiHanDong;
	private int mucPhiDong;
	private String mucDich;
	private String cachThucDong;
	private String thoiGianBatDau;

	public GoiBaoHiem() {
	}

	public GoiBaoHiem( String thoiHanDong, int mucPhiDong, String mucDich, String cachThucDong,
			String thoiGianBatDau) {
		super();
		this.thoiHanDong = thoiHanDong;
		this.mucPhiDong = mucPhiDong;
		this.mucDich = mucDich;
		this.cachThucDong = cachThucDong;
		this.thoiGianBatDau = thoiGianBatDau;
	}

	public void nhap() {
		System.out.print("\t+ Nhap thoi han dong: ");
		this.thoiHanDong = sc.nextLine();
		System.out.println("\t+ Nhap muc phi dong: ");
		String mucPhiDong = sc.nextLine();
		
		do {
			System.out.println("\t+ [Nhap lai kieu so]Nhap muc phi dong: ");
			mucPhiDong = sc.nextLine();
		} while (IntegerException.validate(mucPhiDong) != true);
		
		this.mucPhiDong = Integer.valueOf(mucPhiDong);
		
		System.out.print("\t+ Nhap thoi muc dich: ");
		this.cachThucDong = sc.nextLine();
		System.out.print("\t+ Nhap cach thuc dong: ");
		this.cachThucDong = sc.nextLine();
		System.out.print("\t+ Nhap thoi gian bat dau: ");
		this.thoiGianBatDau = sc.nextLine();
	}

	/**
	 * @return the maBH
	 */
	public int getMaBH() {
		return maBH;
	}

	/**
	 * @param maBH
	 *            the maBH to set
	 */
	public void setMaBH(int maBH) {
		this.maBH = maBH;
	}

	/**
	 * @return the tenGoi
	 */
	public String getTenGoi() {
		return tenGoi;
	}

	/**
	 * @param tenGoi
	 *            the tenGoi to set
	 */
	public void setTenGoi(String tenGoi) {
		this.tenGoi = tenGoi;
	}

	/**
	 * @return the thoiHanDong
	 */
	public String getThoiHanDong() {
		return thoiHanDong;
	}

	/**
	 * @param thoiHanDong
	 *            the thoiHanDong to set
	 */
	public void setThoiHanDong(String thoiHanDong) {
		this.thoiHanDong = thoiHanDong;
	}

	/**
	 * @return the mucPhiDong
	 */
	public int getMucPhiDong() {
		return mucPhiDong;
	}

	/**
	 * @param mucPhiDong
	 *            the mucPhiDong to set
	 */
	public void setMucPhiDong(int mucPhiDong) {
		this.mucPhiDong = mucPhiDong;
	}

	/**
	 * @return the mucDich
	 */
	public String getMucDich() {
		return mucDich;
	}

	/**
	 * @param mucDich
	 *            the mucDich to set
	 */
	public void setMucDich(String mucDich) {
		this.mucDich = mucDich;
	}

	/**
	 * @return the cachThucDong
	 */
	public String getCachThucDong() {
		return cachThucDong;
	}

	/**
	 * @param cachThucDong
	 *            the cachThucDong to set
	 */
	public void setCachThucDong(String cachThucDong) {
		this.cachThucDong = cachThucDong;
	}

	/**
	 * @return the thoiGianBatDau
	 */
	public String getThoiGianBatDau() {
		return thoiGianBatDau;
	}

	/**
	 * @param thoiGianBatDau
	 *            the thoiGianBatDau to set
	 */
	public void setThoiGianBatDau(String thoiGianBatDau) {
		this.thoiGianBatDau = thoiGianBatDau;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String rs = "\nTen Goi: " + tenGoi + 
				"\nThoi Han Dong: " + thoiHanDong + 
				"\nMuc Phi Dong: " + mucPhiDong + 
				"\nMuc Dich: " + mucDich + 
				"\nCach Thuc Dong: " + cachThucDong + 
				"\nThoi Gian Bat Dau: " + thoiGianBatDau;
		return rs;
	}
	
}
