package day5;

import java.util.Scanner;

import customlib.DateException;

public class KhachHang {
	public static final Scanner sc = new Scanner(System.in);
	private String hoTen;
	private String ngaySinh;
	private String noiThuongTru;
	private int cmnd;
	private GoiBaoHiem goiBaoHiem;
	protected int maBH;

	public KhachHang() {
		super();
	}

	public KhachHang(String hoTen, String ngaySinh, String noiThuongTru, int cmnd) {
		super();
		this.hoTen = hoTen;
		this.ngaySinh = ngaySinh;
		this.noiThuongTru = noiThuongTru;
		this.cmnd = cmnd;
	}

	public KhachHang(String hoTen, String ngaySinh, String noiThuongTru, int cmnd, GoiBaoHiem goiBaoHiem) {
		this.hoTen = hoTen;
		this.ngaySinh = ngaySinh;
		this.noiThuongTru = noiThuongTru;
		this.cmnd = cmnd;
		this.goiBaoHiem = goiBaoHiem;
	}

	public KhachHang nhap() {
		KhachHang kh = new KhachHang();
		System.out.println("-----------[Them khach hang]---------");
		System.out.print("\t+Nhap ho ten :");
		kh.setHoTen(sc.nextLine());
		System.out.print("\t+Nhap ngay sinh(dd-MM-yyyy) :");
		kh.setNgaySinh(sc.nextLine());
		do {
			System.out.print("\t+[Nhap lai]ngay sinh(dd-MM-yyyy) :");
			kh.setNgaySinh(sc.nextLine());
		} while (DateException.isDateValid(kh.getNgaySinh()) != true);

		System.out.print("\t+Nhap noi thuong tru :");
		kh.setNoiThuongTru(sc.nextLine());
		System.out.print("\t+Nhap CMND:");
		kh.setCmnd(sc.nextInt());
		return kh;
	}

	/**
	 * @return the hoTen
	 */
	public String getHoTen() {
		return hoTen;
	}

	/**
	 * @param hoTen
	 *            the hoTen to set
	 */
	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	/**
	 * @return the ngaySinh
	 */
	public String getNgaySinh() {
		return ngaySinh;
	}

	/**
	 * @param ngaySinh
	 *            the ngaySinh to set
	 */
	public void setNgaySinh(String ngaySinh) {
		this.ngaySinh = ngaySinh;
	}

	/**
	 * @return the noiThuongTru
	 */
	public String getNoiThuongTru() {
		return noiThuongTru;
	}

	/**
	 * @param noiThuongTru
	 *            the noiThuongTru to set
	 */
	public void setNoiThuongTru(String noiThuongTru) {
		this.noiThuongTru = noiThuongTru;
	}

	/**
	 * @return the cmnd
	 */
	public int getCmnd() {
		return cmnd;
	}

	/**
	 * @param cmnd
	 *            the cmnd to set
	 */
	public void setCmnd(int cmnd) {
		this.cmnd = cmnd;
	}

	/**
	 * @return the goiBaoHiem
	 */
	public GoiBaoHiem getGoiBaoHiem() {
		return goiBaoHiem;
	}

	/**
	 * @param goiBaoHiem
	 *            the goiBaoHiem to set
	 */
	public void setGoiBaoHiem(GoiBaoHiem goiBaoHiem) {
		this.goiBaoHiem = goiBaoHiem;
	}


	@Override
	public String toString() {
		return String.format(this.getClass().getSimpleName() + ", %s, %s, %s, %s, %d",
				hoTen, ngaySinh, noiThuongTru, cmnd, goiBaoHiem.getMaBH());
	}
 
	public String display() {
		String rs = String.format("Ho ten :%s \nNgay sinh :%s\nNoi thuong tru:%s\nCMND :%s", hoTen, ngaySinh,
				noiThuongTru, cmnd);
		return rs;

	}
}
