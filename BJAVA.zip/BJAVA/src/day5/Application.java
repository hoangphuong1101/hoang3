package day5;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import customlib.DatabaseAccess;
import customlib.FileProccessing;

public class Application {
	public static final Scanner sc = new Scanner(System.in);
	DatabaseAccess da = new DatabaseAccess();
	ArrayList<KhachHang> listKH = new ArrayList<>();
	KhachHang kh = new KhachHang();
	GoiBaoHiem bh;
	BaoHiemHopDong bhhd;
	BaoHiemSinhKy bhsk;
	BaoHiemTuVong bhtv;

	public void addKhachHang(KhachHang kh) {
		PreparedStatement ptmt;
		String sql = "INSERT INTO KhachHang(HoTen,NgaySinh,NoiThuongTru,CMND) " + "VALUES(?,?,?,?)";
		try {

			ptmt = da.getConnect().prepareStatement(sql);
			ptmt.setString(1, kh.getHoTen());
			ptmt.setString(2, kh.getNgaySinh());
			ptmt.setString(3, kh.getNoiThuongTru());
			ptmt.setInt(4, kh.getCmnd());

			int rs = ptmt.executeUpdate();
			if (rs == 1) {
				System.out.println("Thanh cong");
				listKH.add(kh);
			} else
				System.out.println("That bai");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			da.closeConnetion();
		}
	}

	public void delKhachHang(KhachHang kh) {
		PreparedStatement ptmt;
		String sql = "DELETE KhachHang WHERE CMND = ?";
		try {
			ptmt = da.getConnect().prepareStatement(sql);
			ptmt.setInt(1, kh.getCmnd());

			int rs = ptmt.executeUpdate();
			if (rs == 1) {
				System.out.println("Thanh cong");
				listKH.remove(kh);
			} else
				System.out.println("That bai");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			da.closeConnetion();
		}
	}

	public void updateKhachHang(KhachHang kh) {
		PreparedStatement ptmt;
		String sql = "Update KhachHang " + "Set HoTen = ?,NgaySinh = ?,NoiThuongTru = ?,CMND = ? " + "WHERE CMND = ?";
		try {
			ptmt = da.getConnect().prepareStatement(sql);
			ptmt.setString(1, kh.getHoTen());
			ptmt.setString(2, kh.getNgaySinh());
			ptmt.setString(3, kh.getNoiThuongTru());
			ptmt.setInt(4, kh.getCmnd());

			int rs = ptmt.executeUpdate();
			if (rs == 1) {
				System.out.println("Thanh cong");
			} else
				System.out.println("That bai");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			da.closeConnetion();
		}
	}

	public void dangKyGoiBH() {
		this.bh.nhap();
	}

	public void addBHTV(GoiBaoHiem bh) {
		BaoHiemTuVong bhtv = (BaoHiemTuVong) bh;
		PreparedStatement ptmt;
		String sql = "INSERT INTO BaoHiem(TenGoi,ThoiHanDong,MucPhiDong,MucDich,CachThucDong,ThoiGianBatDau,TruongHopDong,ThoiGianToiThieu)"
				+ " VALUES(?,?,?,?,?,?,?,?)";
		try {
			ptmt = da.getConnect().prepareStatement(sql);
			ptmt.setString(1, bhtv.getClass().getSimpleName());
			ptmt.setString(2, bhtv.getThoiHanDong());
			ptmt.setInt(3, bhtv.getMucPhiDong());
			ptmt.setString(4, bhtv.getMucDich());
			ptmt.setString(5, bhtv.getCachThucDong());
			ptmt.setString(6, bhtv.getThoiGianBatDau());
			ptmt.setString(7, bhtv.getTruongHopDong());
			ptmt.setString(8, bhtv.getThoiGianToiThieu());

			int rs = ptmt.executeUpdate();
			if (rs == 1) {
				System.out.println("Them bao hiem tu vong thanh cong");
			} else {
				System.out.println("Them bao hiem tu vong that bai");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Loi tai KhachHang.getKH()");
		} finally {
			da.closeConnetion();
		}
	}

	public void addBHSK(GoiBaoHiem bh) {
		BaoHiemSinhKy bhsk = (BaoHiemSinhKy) bh;
		PreparedStatement ptmt;
		String sql = "INSERT INTO BaoHiem(TenGoi,ThoiHanDong,MucPhiDong,MucDich,CachThucDong,ThoiGianBatDau,ThoiGianKetThuc,ThoiGianTroCap)"
				+ " VALUES(?,?,?,?,?,?,?,?)";
		try {
			ptmt = da.getConnect().prepareStatement(sql);
			ptmt.setString(1, bhsk.getClass().getSimpleName());
			ptmt.setString(2, bhsk.getThoiHanDong());
			ptmt.setInt(3, bhsk.getMucPhiDong());
			ptmt.setString(4, bhsk.getMucDich());
			ptmt.setString(5, bhsk.getCachThucDong());
			ptmt.setString(6, bhsk.getThoiGianBatDau());
			ptmt.setString(7, bhsk.getThoiGianKetThuc());
			ptmt.setString(8, bhsk.getThoiGianTroCap());

			int rs = ptmt.executeUpdate();
			if (rs == 1) {
				System.out.println("Them bao hiem sinh ky thanh cong");
			} else {
				System.out.println("Them bao hiem sinh ky that bai");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Loi tai KhachHang.getKH()");
		} finally {
			da.closeConnetion();
		}
	}

	public void addBHHD(GoiBaoHiem bh) {
		BaoHiemHopDong bhhd = (BaoHiemHopDong) bh;
		PreparedStatement ptmt;
		String sql = "INSERT INTO BaoHiem(TenGoi,ThoiHanDong,MucPhiDong,MucDich,CachThucDong,ThoiGianBatDau,ThoiGianKetThuc,BenhHiemNgheo,TroCapNamVien,BaoHiemThuongTatVV)"
				+ " VALUES(?,?,?,?,?,?,?,?,?,?)";
		try {
			ptmt = da.getConnect().prepareStatement(sql);
			ptmt.setString(1, bhhd.getClass().getSimpleName());
			ptmt.setString(2, bhhd.getThoiHanDong());
			ptmt.setInt(3, bhhd.getMucPhiDong());
			ptmt.setString(4, bhhd.getMucDich());
			ptmt.setString(5, bhhd.getCachThucDong());
			ptmt.setString(6, bhhd.getThoiGianBatDau());
			ptmt.setString(7, bhhd.getThoiGianKetThuc());
			ptmt.setString(8, bhhd.getBenhHiemNgheo());
			ptmt.setString(9, bhhd.getTroCapNamVien());
			ptmt.setString(10, bhhd.getBaoHiemThuongTatVV());

			int rs = ptmt.executeUpdate();
			if (rs == 1) {
				System.out.println("Them bao hiem sinh ky thanh cong");
			} else {
				System.out.println("Them bao hiem sinh ky that bai");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Loi tai KhachHang.getKH()");
		} finally {
			da.closeConnetion();
		}
	}

	public void getKH() {
		PreparedStatement ptmt;
		String sql = "SELECT TOP 1 * FROM KhachHang";
		try {
			ptmt = da.getConnect().prepareStatement(sql);

			ResultSet rs = ptmt.executeQuery();

			while (rs.next()) {
				kh = new KhachHang();
				kh.setHoTen(rs.getString("HoTen"));
				kh.setNgaySinh(rs.getString("NgaySinh"));
				kh.setNoiThuongTru(rs.getString("NoiThuongTru"));
				kh.setCmnd(rs.getInt("CMND"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Loi tai KhachHang.getKH()");
		} finally {
			da.closeConnetion();
		}
	}

	public void execute() {
		display();
		int n = this.getInput();
		switch (n) {
		case 1:
			kh = kh.nhap();
			addKhachHang(kh);
			execute1();
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			getImfoKH();
			execute();
			break;
		}
	}

	public void execute1() {
		display1();
		int n = this.getInput();
		switch (n) {
		case 1:
			bh = new BaoHiemTuVong();
			dangKyGoiBH();
			addBHTV(bh);
			execute();
			break;
		case 2:
			bh = new BaoHiemSinhKy();
			dangKyGoiBH();
			addBHSK(bh);
			execute();
			break;
		case 3:
			bh = new BaoHiemHopDong();
			dangKyGoiBH();
			addBHHD(bh);
			execute();
			break;
		case 4:
			execute();
			break;
		}
	}

	public void getImfoKH() {
		this.getKH();
		System.out.println("-------[Thong tin khach hang]-------");
	
		for (int i = 0; i < getAllKhachHang().size(); i++) {
			System.out.println("\n-----<< Khach Hang " + (i + 1) + " >>----");
			System.out.println(kh.display());
			try {
				if (kh.getGoiBaoHiem() != null)
					System.out.println(kh.getGoiBaoHiem());
			} catch (NullPointerException e) {
				System.out.println("Khach hang chua dang ky goi bao hiem nao !");
			} catch (Exception e) {
				System.err.print("Loi tai getImfoKh()");
			}
			System.out.println("---------------------------------");
		}
	}

	public int getInput() {
		try {
			System.out.print("->>Nhap mot so :");
			int input = sc.nextInt();
			return input;
		} catch (NumberFormatException e) {
			System.out.println("[Thong bao] Chi duoc nhap so");
		}
		return 0;
	}

	public void display() {
		System.out.println("------[Chuong trinh]-----");
		System.out.println("1. Them Khach hang ");
		System.out.println("2. Cap nhat khach hang");
		System.out.println("3. Xoa Khach hang");
		System.out.println("4. Hien thi thong tin khach hang");
		System.out.println("-------------------------");
	}

	public void display1() {
		System.out.println("------[Dang ky goi bao hiem]-----");
		System.out.println("1. Bao Hiem Tu Vong ");
		System.out.println("2. Bao Hiem Sinh Ky ");
		System.out.println("3. Bao Hiem Hop Dong ");
		System.out.println("4. Khong dang ky");
		System.out.println("-------------------------");
	}

	public ArrayList<KhachHang> getAllKhachHang() {
		ArrayList<KhachHang> listKH = new ArrayList<>();
		PreparedStatement ptmt;
		String sql = "SELECT * FROM KhachHang";
		try {
			ptmt = da.getConnect().prepareStatement(sql);

			ResultSet rs = ptmt.executeQuery();

			while (rs.next()) {
				kh = new KhachHang();
				kh.setHoTen(rs.getString("HoTen"));
				kh.setNgaySinh(rs.getString("NgaySinh"));
				kh.setNoiThuongTru(rs.getString("NoiThuongTru"));
				kh.setCmnd(rs.getInt("CMND"));
				kh.maBH = rs.getInt("MaBH");
//				kh.setGoiBaoHiem(getGoiBaoHiem(kh.maBH));
				listKH.add(kh);
			}
//			addBHToKhachHang(listKH);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Loi tai KhachHang.getKH()");
		} finally {
			da.closeConnetion();
		}
		return listKH;
	}

	public void addBHToKhachHang(ArrayList<KhachHang> listKH) {
		for (KhachHang m : listKH) {
			if (m.maBH == 1) {
				m.setGoiBaoHiem(getGoiBaoHiem(m.maBH));
				System.out.println(getGoiBaoHiem(m.maBH));
			}
		}
	}

	public GoiBaoHiem getGoiBaoHiem(int maBH) {
		PreparedStatement ptmt;
		String sql = "SELECT * FROM BaoHiem WHERE MaBH = ?";
		try {
			ptmt = da.getConnect().prepareStatement(sql);
			ptmt.setInt(1, maBH);
			ResultSet rs = ptmt.executeQuery();
			while (rs.next()) {
				String tenLoaiBH = rs.getString("TenGoi");
				System.out.println("test"+tenLoaiBH);
				if (tenLoaiBH.equals("BaoHiemHopDong")) {
					BaoHiemHopDong bhhd = new BaoHiemHopDong();
					bhhd.setMaBH(maBH);
					bhhd.setBaoHiemThuongTatVV(rs.getString("baoHiemThuongTatVV"));
					bhhd.setBenhHiemNgheo(rs.getString("benhHiemNgheo"));
					bhhd.setCachThucDong(rs.getString("cachThucDong"));
					bhhd.setMucDich(rs.getString("MucDich"));
					bhhd.setMucPhiDong(rs.getInt("mucPhiDong"));
					bhhd.setTenGoi(rs.getString("TenGoi"));
					bhhd.setThoiGianBatDau(rs.getString("thoiGianBatDau"));
					bhhd.setThoiGianKetThuc(rs.getString("thoiGianKetThuc"));
					bhhd.setThoiHanDong(rs.getString("thoiHanDong"));
					bhhd.setTroCapNamVien(rs.getString("TroCapNamVien"));

					return bhhd;
				} else if (tenLoaiBH.equals("BaoHiemSinhKy")) {
					BaoHiemSinhKy bhsk = new BaoHiemSinhKy();
					bhsk.setMaBH(maBH);
					bhsk.setCachThucDong(rs.getString("cachThucDong"));
					bhsk.setMucDich(rs.getString("MucDich"));
					bhsk.setMucPhiDong(rs.getInt("mucPhiDong"));
					bhsk.setTenGoi(rs.getString("TenGoi"));
					bhsk.setThoiGianBatDau(rs.getString("thoiGianBatDau"));
					bhsk.setThoiGianKetThuc(rs.getString("thoiGianKetThuc"));
					bhsk.setThoiHanDong(rs.getString("thoiHanDong"));
					bhsk.setThoiGianTroCap(rs.getString("thoiGianTroCap"));
					return bhsk;
				} else if (tenLoaiBH.equals("BaoHiemSinhKy")) {
					BaoHiemTuVong bhtv = new BaoHiemTuVong();
					bhtv.setMaBH(maBH);
					bhtv.setCachThucDong(rs.getString("cachThucDong"));
					bhtv.setMucDich(rs.getString("MucDich"));
					bhtv.setMucPhiDong(rs.getInt("mucPhiDong"));
					bhtv.setTenGoi(rs.getString("TenGoi"));
					bhtv.setThoiGianBatDau(rs.getString("thoiGianBatDau"));
					bhtv.setThoiHanDong(rs.getString("thoiHanDong"));
					bhtv.setThoiGianToiThieu(rs.getString("thoiGianToiThieu"));
					bhtv.setCachThucDong(rs.getString("CachThucDong"));
					return bhtv;
				} else{
					System.out.println("Loi");
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Loi tai KhachHang.getKH()");
		} finally {
			da.closeConnetion();
		}
		return null;
	}

	public static void main(String[] args) {
		Application app = new Application();
		app.execute();
		// FileProccessing fp = new FileProccessing();
		// fp.setfInput("D:\\File\\input.txt");
		// fp.setfOutput("D:\\File\\output.txt");
		// fp.writeFile(app.getAllKhachHang());
		// System.out.println(app.getGoiBaoHiem(1));
	}
}
