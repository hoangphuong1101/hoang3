package javacore;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NumberPlateException extends Exception{
	private Pattern pattern;
	private Matcher matcher;

	private static final String PHONE_PATTERN = "[0-9]{5}";

	public NumberPlateException() {
		pattern = Pattern.compile(PHONE_PATTERN);
	}

	/**
	 * Validate hex with regular expression
	 *
	 * @param hex
	 *            hex for validation
	 * @return true valid hex, false invalid hex
	 * @throws NumberPlateException 
	 */
	// checked exception
	public void validate(String hex) throws NumberPlateException {
		matcher = pattern.matcher(hex);
		if(matcher.matches() != true){
			throw new NumberPlateException();
		}
	}
	
	@Override
	public String getMessage() {
		return "Loi NumberPlate !";
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap :");
		String s = sc.nextLine();
		NumberPlateException e = new NumberPlateException();
		try {
			e.validate(s);
		} catch (NumberPlateException e1) {
			System.out.println(e1.getMessage());
		}
	}
	
}
