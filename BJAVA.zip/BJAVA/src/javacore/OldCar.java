package javacore;

public class OldCar extends Car {
	private String actionDuration;

	public OldCar() {
		super();
	}

	/**
	 * @param numberPlate
	 * @param yearOfManufacture
	 * @param brand
	 * @param haveInsurance
	 * @param insuranceRegistStartDate
	 * @param actionDuration
	 */
	public OldCar(String numberPlate, String yearOfManufacture, String brand, String haveInsurance,
			String insuranceRegistStartDate, String actionDuration) {
		super(numberPlate, yearOfManufacture, brand, haveInsurance, insuranceRegistStartDate);
		this.actionDuration = actionDuration;
	}

	/**
	 * @return the actionDuration
	 */
	public String getActionDuration() {
		return actionDuration;
	}

	/**
	 * @param actionDuration
	 *            the actionDuration to set
	 */
	public void setActionDuration(String actionDuration) {
		this.actionDuration = actionDuration;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javacore.Car#nhap()
	 */
	@Override
	public void nhap() {
		super.nhap();
		System.out.print("Nhap so nam lua hanh(int): ");
		this.actionDuration = sc.nextLine();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javacore.Car#showMyInfo()
	 */
	@Override
	public void showMyInfo() {
		System.out.println("-----" + this.getClass().getSimpleName() + "-----");
		super.showMyInfo();
		System.out.println("OldCar [actionDuration=" + actionDuration + "]");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OldCar [actionDuration=" + actionDuration + "]";
	}

	@Override
	public int compareTo(Car c) {
		int car1 = Integer.valueOf(this.getYearOfManufacture());
		int car2 = Integer.valueOf(c.getYearOfManufacture());
		if (Integer.compare(car1, car2) != 0) {
			return Integer.compare(car1, car2);
		} else {
			int bh1 = Integer.valueOf(this.getInsuranceRegistStartDate());
			int bh2 = Integer.valueOf(c.getInsuranceRegistStartDate());
			return Integer.compare(bh1, bh2);
		}

	}
}
