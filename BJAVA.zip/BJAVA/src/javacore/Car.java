package javacore;

import java.util.ArrayList;
import java.util.Scanner;

public abstract class Car implements Comparable<Car>{
	private String numberPlate;
	private String yearOfManufacture;
	private String brand;
	private String haveInsurance;
	private String insuranceRegistStartDate;
	public static int cardCount;
	public static final Scanner sc = new Scanner(System.in);
	protected ArrayList<CarPackage> pack = new ArrayList<CarPackage>();

	public Car() {
		super();
	}

	public Car(String numberPlate, String yearOfManufacture, String brand, String haveInsurance,
			String insuranceRegistStartDate) {
		super();
		this.numberPlate = numberPlate;
		this.yearOfManufacture = yearOfManufacture;
		this.brand = brand;
		this.haveInsurance = haveInsurance;
		this.insuranceRegistStartDate = insuranceRegistStartDate;
	}

	public void showMyInfo() {
		System.out.println("Car [numberPlate=" + numberPlate + ", yearOfManufacture=" + yearOfManufacture + ", brand=" + brand
				+ ", haveInsurance=" + haveInsurance + ", insuranceRegistStartDate=" + insuranceRegistStartDate + "]");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Car [numberPlate=" + numberPlate + ", yearOfManufacture=" + yearOfManufacture + ", brand=" + brand
				+ ", haveInsurance=" + haveInsurance + ", insuranceRegistStartDate=" + insuranceRegistStartDate
				+ ", getNumberPlate()=" + getNumberPlate() + ", getYearOfManufacture()=" + getYearOfManufacture()
				+ ", getBrand()=" + getBrand() + ", getHaveInsurance()=" + getHaveInsurance()
				+ ", getInsuranceRegistStartDate()=" + getInsuranceRegistStartDate() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	/**
	 * @return the numberPlate
	 */
	public String getNumberPlate() {
		return numberPlate;
	}

	/**
	 * @param numberPlate
	 *            the numberPlate to set
	 */
	public void setNumberPlate(String numberPlate) {
		this.numberPlate = numberPlate;
	}

	/**
	 * @return the yearOfManufacture
	 */
	public String getYearOfManufacture() {
		return yearOfManufacture;
	}

	/**
	 * @param yearOfManufacture
	 *            the yearOfManufacture to set
	 */
	public void setYearOfManufacture(String yearOfManufacture) {
		this.yearOfManufacture = yearOfManufacture;
	}

	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * @param brand
	 *            the brand to set
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * @return the haveInsurance
	 */
	public String getHaveInsurance() {
		return haveInsurance;
	}

	/**
	 * @param haveInsurance
	 *            the haveInsurance to set
	 */
	public void setHaveInsurance(String haveInsurance) {
		this.haveInsurance = haveInsurance;
	}

	/**
	 * @return the insuranceRegistStartDate
	 */
	public String getInsuranceRegistStartDate() {
		return insuranceRegistStartDate;
	}

	/**
	 * @param insuranceRegistStartDate
	 *            the insuranceRegistStartDate to set
	 */
	public void setInsuranceRegistStartDate(String insuranceRegistStartDate) {
		this.insuranceRegistStartDate = insuranceRegistStartDate;
	}

	public void nhap() {
		System.out.print("Nhap bien kiem soat: ");
		this.numberPlate = sc.nextLine();

		NumberPlateException np = new NumberPlateException();
//		try {
//			if (np.validate(this.getNumberPlate()) != true) {
//				throw new NumberPlateException();
//			}
//		} catch (NumberPlateException e) {
//			System.out.println("(E):" + e.getMessage());
//			System.out.println("He thong da xay ra su co khong mon muon. Thanh that xin loi !!!");
//		}

		System.out.print("Nhap bien nam san xuat : ");
		this.yearOfManufacture = sc.nextLine();
		System.out.print("Nhap bien hang SX: ");
		this.brand = sc.nextLine();
		try {
			if (BrandException.validate(this.brand) != true) {
				throw new BrandException();
			}
		} catch (BrandException e) {
			System.out.println("(E):" + e.getMessage());
			System.out.println("He thong da xay ra su co khong mon muon. Thanh that xin loi !!!");
		}
		System.out.print("Nhap bien da mua bao hiem: ");
		this.haveInsurance = sc.nextLine();
		System.out.print("Nhap ngay bat dau mua bao hiem: ");
		this.insuranceRegistStartDate = sc.nextLine();
	}
}
