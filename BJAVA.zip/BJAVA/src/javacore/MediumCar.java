package javacore;

public class MediumCar extends Car {
	private String havePowerSteering;

	/**
	 * 
	 */
	public MediumCar() {
		super();
	}

	/**
	 * @param numberPlate
	 * @param yearOfManufacture
	 * @param brand
	 * @param haveInsurance
	 * @param insuranceRegistStartDate
	 * @param havePowerSteering
	 */
	public MediumCar(String numberPlate, String yearOfManufacture, String brand, String haveInsurance,
			String insuranceRegistStartDate, String havePowerSteering) {
		super(numberPlate, yearOfManufacture, brand, haveInsurance, insuranceRegistStartDate);
		this.havePowerSteering = havePowerSteering;
	}

	/**
	 * @return the havePowerSteering
	 */
	public String getHavePowerSteering() {
		return havePowerSteering;
	}

	/**
	 * @param havePowerSteering
	 *            the havePowerSteering to set
	 */
	public void setHavePowerSteering(String havePowerSteering) {
		this.havePowerSteering = havePowerSteering;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MediumCar [havePowerSteering=" + havePowerSteering + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javacore.Car#showMyInfo()
	 */
	@Override
	public void showMyInfo() {
		// TODO Auto-generated method stub
		System.out.println("-----"+this.getClass().getSimpleName()+"-----");
		super.showMyInfo();
		System.out.println(toString());
	}

	/* (non-Javadoc)
	 * @see javacore.Car#nhap()
	 */
	@Override
	public void nhap(){
		super.nhap();
		System.out.print("Nhap co tay lai tro luc: ");
		this.havePowerSteering = sc.nextLine();
	}

	@Override
	public int compareTo(Car c) {
		int car1 = Integer.valueOf(this.getYearOfManufacture());
		int car2 = Integer.valueOf(c.getYearOfManufacture());
		if(Integer.compare(car1, car2) != 0){
			return -1*Integer.compare(car1, car2);
		}else{
			int bh1 = Integer.valueOf(this.getInsuranceRegistStartDate());
			int bh2 = Integer.valueOf(c.getInsuranceRegistStartDate());
			return -1*Integer.compare(bh1, bh2);
		}
		
	}
	
}
