package javacore;

import java.util.ArrayList;
import java.util.Collections;

import day5.KhachHang;

public class App {
	public static void countCar() {
		System.out.println(Car.cardCount);
	}

	public static void oldCar() {
		System.out.println("----------<< ADD OldCar >>----------");
		OldCar car = new OldCar();
		car.nhap();
		car.showMyInfo();
		DataAccess.addOldCar(car);
	}

	public static void modernCar() {
		System.out.println("----------<< ADD ModernCar >>----------");
		ModernCar car = new ModernCar();
		car.nhap();
		car.showMyInfo();
		DataAccess.addModernCar(car);
	}

	public static MediumCar mediumCar() {
		System.out.println("----------<< ADD MediumCar >>----------");
		MediumCar car = new MediumCar();
		car.nhap();
		car.showMyInfo();
		DataAccess.addMediumCar(car);
		return car;
	}

	public static void main(String[] args) {
		ArrayList<CarPackage> packs = new ArrayList<CarPackage>();
//		packs.add(new CarPackage(1, "packageA", "70 trieu"));
//		packs.add(new CarPackage(2, "packageA", "70 trieu"));
//		packs.add(new CarPackage(3, "packageA", "70 trieu"));
		DataAccess.createTable(new KhachHang());
		//
//		 DataAccess.addMediumCar1(mediumCar(), packs.get(1));
//		 modernCar();
		// oldCar();
		// System.out.println("[KQ] Count car:" + Car.cardCount);
//		for (Car car : DataAccess.getAllCar1()) {
//			car.showMyInfo();		}
//		Collections.sort(DataAccess.getAllCar1());
//		System.out.println("--------------");
//		for (Car car : DataAccess.getAllCar1()) {
//			car.showMyInfo();
//		}
//		DataAccess.createTable(new KhachHang());
	}
}
