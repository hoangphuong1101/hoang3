package javacore;

public class CarPackage {
	private int id;
	private String name;
	private String value;

	/**
	 * 
	 */
	public CarPackage() {
		super();
	}

	/**
	 * @param name
	 * @param value
	 */
	public CarPackage(String name, String value) {
		super();
		this.name = name;
		this.value = value;
	}

	/**
	 * @param id
	 * @param name
	 * @param value
	 */
	public CarPackage(int id, String name, String value) {
		super();
		this.id = id;
		this.name = name;
		this.value = value;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CarPackage [name=" + name + ", value=" + value + "]";
	}

}
