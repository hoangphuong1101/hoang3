package javacore;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;

import com.sun.xml.internal.bind.v2.schemagen.episode.Package;

public class DataAccess {

	public static Connection getSQLServerConnection() throws SQLException, ClassNotFoundException {
		String hostName = "localhost";
		String sqlInstanceName = "SQLEXPRESS";
		String database = "Mock";
		String userName = "binhnd";
		String password = "Binh123456";
		return getSQLServerConnection(hostName, sqlInstanceName, database, userName, password);
	}

	public static Connection getSQLServerConnection(String hostName, String sqlInstanceName, String database,
			String userName, String password) throws ClassNotFoundException, SQLException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		String connectionURL = "jdbc:sqlserver://" + hostName + ":1433" + ";instance=" + sqlInstanceName
				+ ";databaseName=" + database;

		Connection conn = DriverManager.getConnection(connectionURL, userName, password);
		return conn;
	}

	public static void createTable(Object obj) {

		// Get all attribute
		ArrayList<String> attributes = new ArrayList<>();

		for (Method m : obj.getClass().getMethods()) {
			if (m.getName().indexOf("get") == 0 && m.getName().indexOf("getClass") != 0) {
				attributes.add(m.getName().substring(3));
			}
		}

		// Sort attributes: SuperClass -> SubClass
		for (Method m : obj.getClass().getDeclaredMethods()) {
			if (m.getName().indexOf("get") == 0 && m.getName().indexOf("getClass") != 0) {
				if (attributes.contains(m.getName().substring(3)) == true) {
					attributes.remove(m.getName().substring(3));
					attributes.add(m.getName().substring(3));
				}
			}
		}

		// Create table
		StringBuffer sql = new StringBuffer("CREATE TABLE " + obj.getClass().getSimpleName() + "(");
		for (String m : attributes) {
			sql.append(m + " nvarchar(100) ,");
		}
		sql.append(")");

		// Execute query
		String sqlRS = sql.toString();
		PreparedStatement ptmt = null;
		Connection con = null;
		try {
			con = getSQLServerConnection();
			ptmt = con.prepareCall(sqlRS);
			int rs = ptmt.executeUpdate();

			if (rs == 0) {
				System.out.println("Created a table successful !");
			} else {
				System.out.println("Fail");
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.err.println("BUG:" + e.getMessage());
		} catch (Exception e) {
			System.err.println("BUG:" + e.getMessage());
		} finally {
			closeConnection(con);
		}
	}

	public static HashMap<String, String> getAttributesByOject(Object obj, int[] rules) {
		// Get all attribute
		ArrayList<String> attributes = new ArrayList<>();

		for (Method m : obj.getClass().getMethods()) {
			if (m.getName().indexOf("get") == 0 && m.getName().indexOf("getClass") != 0) {
				attributes.add(m.getName().substring(3));
			}
		}

		// Sort attributes: SuperClass -> SubClass
		for (Method m : obj.getClass().getDeclaredMethods()) {
			if (m.getName().indexOf("get") == 0 && m.getName().indexOf("getClass") != 0) {
				if (attributes.contains(m.getName().substring(3)) == true) {
					attributes.remove(m.getName().substring(3));
					attributes.add(m.getName().substring(3));
				}
			}
		}
		// Lam chua xong lay du lieu doi tuong thong qua ham toString ->
		// Hashtable
		return null;

	}

	public static void closeConnection(Connection con) {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unused")
	public static boolean addDataIntoTable(String sql) {
		Connection con = null;
		PreparedStatement ptmt;
		try {
			con = getSQLServerConnection();
			ptmt = con.prepareStatement(sql);
			return true;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.err.println("BUG:" + e.getMessage());
		} finally {
			closeConnection(con);
		}
		return false;
	}

	public static void addModernCar(ModernCar car) {
		Connection con = null;

		String sql = "INSERT INTO Car(numberPlate,yearOfManufacture,brand,haveInsurance,[InsuranceRegistStartDate],"
				+ "havePositioningDevice,backSenSor)" + " VALUES(?,?,?,?,?,?,?)";

		/**
		 * @param numberPlate
		 *            1
		 * @param yearOfManufacture
		 *            2
		 * @param brand
		 *            3
		 * @param haveInsurance
		 *            4
		 * @param insuranceRegistStartDate
		 *            5
		 * @param havePositioningDevice
		 *            6
		 * @param backSenSor
		 *            7
		 */
		try {
			con = getSQLServerConnection();
			PreparedStatement ptmt = con.prepareStatement(sql);
			ptmt.setString(1, car.getNumberPlate());
			ptmt.setString(2, car.getYearOfManufacture());
			ptmt.setString(3, car.getBrand());
			ptmt.setString(4, car.getHaveInsurance());
			ptmt.setString(5, car.getInsuranceRegistStartDate());
			ptmt.setString(6, car.getHavePositioningDevice());
			ptmt.setString(7, car.getBackSenSor());
			int rs = ptmt.executeUpdate();
			if (rs > 0) {
				System.out.println("OK");
				Car.cardCount++;
				System.out.println(car.cardCount);
			} else {
				System.out.println("Not good");
			}

		} catch (SQLException e) {
			System.out.println("SQL: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		} finally {
			closeConnection(con);
		}
	}

	public static void addModernCar1(ModernCar car, CarPackage p) {
		Connection con = null;

		String sql = "INSERT INTO Car(numberPlate,yearOfManufacture,brand,haveInsurance,[InsuranceRegistStartDate],"
				+ "havePositioningDevice,backSenSor)" + " VALUES(?,?,?,?,?,?,?)";
		String sql1 = "INSERT INTO CarPackage(CarId,PId)" + " VALUES(?,?)";

		/**
		 * @param numberPlate
		 *            1
		 * @param yearOfManufacture
		 *            2
		 * @param brand
		 *            3
		 * @param haveInsurance
		 *            4
		 * @param insuranceRegistStartDate
		 *            5
		 * @param havePositioningDevice
		 *            6
		 * @param backSenSor
		 *            7
		 */
		try {
			con = getSQLServerConnection();
			PreparedStatement ptmt = con.prepareStatement(sql);
			ptmt.setString(1, car.getNumberPlate());
			ptmt.setString(2, car.getYearOfManufacture());
			ptmt.setString(3, car.getBrand());
			ptmt.setString(4, car.getHaveInsurance());
			ptmt.setString(5, car.getInsuranceRegistStartDate());
			ptmt.setString(6, car.getHavePositioningDevice());
			ptmt.setString(7, car.getBackSenSor());
			int rs = ptmt.executeUpdate();
			if (rs > 0) {
				System.out.println("OK");
				Car.cardCount++;
				System.out.println(car.cardCount);
			} else {
				System.out.println("Not good");
			}
			ptmt = con.prepareStatement(sql1);
			ptmt.setInt(1, Car.cardCount);
			ptmt.setInt(2, p.getId());

			rs = ptmt.executeUpdate();
			if (rs > 0) {
				System.out.println("OK");
			} else {
				System.out.println("Not good");
			}

		} catch (SQLException e) {
			System.out.println("SQL: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		} finally {
			closeConnection(con);
		}
	}

	public static void addMediumCar(MediumCar car) {
		Connection con = null;

		String sql = "INSERT INTO Car(numberPlate,yearOfManufacture,brand,haveInsurance,[InsuranceRegistStartDate],"
				+ "HavePowerSteering)" + " VALUES(?,?,?,?,?,?)";
		/**
		 * @param numberPlate
		 * @param yearOfManufacture
		 * @param brand
		 * @param haveInsurance
		 * @param insuranceRegistStartDate
		 * @param havePowerSteering
		 */
		try {
			con = getSQLServerConnection();
			PreparedStatement ptmt = con.prepareStatement(sql);
			ptmt.setString(1, car.getNumberPlate());
			ptmt.setString(2, car.getYearOfManufacture());
			ptmt.setString(3, car.getBrand());
			ptmt.setString(4, car.getHaveInsurance());
			ptmt.setString(5, car.getInsuranceRegistStartDate());
			ptmt.setString(6, car.getHavePowerSteering());
			int rs = ptmt.executeUpdate();
			if (rs > 0) {
				System.out.println("OK");
				Car.cardCount++;
				System.out.println(Car.cardCount);

			} else {
				System.out.println("Not good");
			}
			

		} catch (SQLException e) {
			System.out.println("SQL: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		} finally {
			closeConnection(con);
		}
	}

	public static void addMediumCar1(MediumCar car, CarPackage p) {
		Connection con = null;

		String sql = "INSERT INTO Car(numberPlate,yearOfManufacture,brand,haveInsurance,[InsuranceRegistStartDate],"
				+ "HavePowerSteering)" + " VALUES(?,?,?,?,?,?)";
		String sql1 = "INSERT INTO CarPackage(CarId,PId)" + " VALUES(?,?)";
		/**
		 * @param numberPlate
		 * @param yearOfManufacture
		 * @param brand
		 * @param haveInsurance
		 * @param insuranceRegistStartDate
		 * @param havePowerSteering
		 */
		try {
			con = getSQLServerConnection();
			PreparedStatement ptmt = con.prepareStatement(sql);
			ptmt.setString(1, car.getNumberPlate());
			ptmt.setString(2, car.getYearOfManufacture());
			ptmt.setString(3, car.getBrand());
			ptmt.setString(4, car.getHaveInsurance());
			ptmt.setString(5, car.getInsuranceRegistStartDate());
			ptmt.setString(6, car.getHavePowerSteering());
			int rs = ptmt.executeUpdate();
			if (rs > 0) {
				System.out.println("OK");
				Car.cardCount++;
				System.out.println(Car.cardCount);

			} else {
				System.out.println("Not good");
			}
			ptmt = con.prepareStatement(sql1);
			ptmt.setInt(1, Car.cardCount);
			ptmt.setInt(2, p.getId());

			rs = ptmt.executeUpdate();
			if (rs > 0) {
				System.out.println("OK");
			} else {
				System.out.println("Not good");
			}
		} catch (SQLException e) {
			System.out.println("SQL: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		} finally {
			closeConnection(con);
		}
	}

	public static void addOldCar(OldCar car) {
		Connection con = null;

		String sql = "INSERT INTO Car(numberPlate,yearOfManufacture,brand,haveInsurance,[InsuranceRegistStartDate],"
				+ "ActionDuration)" + " VALUES(?,?,?,?,?,?)";
		/**
		 * @param numberPlate
		 * @param yearOfManufacture
		 * @param brand
		 * @param haveInsurance
		 * @param insuranceRegistStartDate
		 * @param actionDuration
		 */
		try {
			con = getSQLServerConnection();
			PreparedStatement ptmt = con.prepareStatement(sql);
			ptmt.setString(1, car.getNumberPlate());
			ptmt.setString(2, car.getYearOfManufacture());
			ptmt.setString(3, car.getBrand());
			ptmt.setString(4, car.getHaveInsurance());
			ptmt.setString(5, car.getInsuranceRegistStartDate());
			ptmt.setString(6, car.getActionDuration());
			int rs = ptmt.executeUpdate();
			if (rs > 0) {
				System.out.println("OK");
				Car.cardCount++;
				System.out.println(Car.cardCount);
			} else {
				System.out.println("Not good");
			}

		} catch (SQLException e) {
			System.out.println("SQL: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		} finally {
			closeConnection(con);
		}
	}

	public static void getAllCar() {
		Connection con = null;

		String sql = "SELECT * FROM Car";

		try {
			con = getSQLServerConnection();
			PreparedStatement ptmt = con.prepareStatement(sql);
			ResultSet rs = ptmt.executeQuery();
			while (rs.next() != false) {
				System.out.println();
				System.out.print(rs.getString("YearOfManufacture"));
				System.out.print(rs.getString("NumberPlate"));
				System.out.print(rs.getString("HaveInsurance"));
				System.out.print(rs.getString("Brand"));
				System.out.print(rs.getString("BackSenSor"));
				System.out.print(rs.getString("HavePositioningDevice"));
				System.out.print(rs.getString("HavePowerSteering"));
				System.out.print(rs.getString("ActionDuration"));
			}

		} catch (SQLException e) {
			System.out.println("SQL: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		} finally {
			closeConnection(con);
		}
	}
	
	public static ArrayList<Car> getAllCar1() {
		Connection con = null;
		ArrayList<Car> cars = new ArrayList<>();
		String sql = "SELECT * FROM Car";

		try {
			con = getSQLServerConnection();
			PreparedStatement ptmt = con.prepareStatement(sql);
			ResultSet rs = ptmt.executeQuery();
		
			while (rs.next() != false) {
				if(rs.getString("ActionDuration")!= null){
					OldCar car = new OldCar(rs.getString("numberPlate"),rs.getString("yearOfManufacture"), rs.getString("brand"), rs.getString("haveInsurance"), rs.getString("insuranceRegistStartDate"), rs.getString("insuranceRegistStartDate"));
					cars.add(car);
				}else
				
				if(rs.getString("HavePowerSteering") != null){
					MediumCar car = new MediumCar(rs.getString("numberPlate"), rs.getString("yearOfManufacture"), rs.getString("brand"), rs.getString("haveInsurance"), rs.getString("insuranceRegistStartDate"), rs.getString("havePowerSteering"));
					cars.add(car);
				}else{
					ModernCar car = new ModernCar(rs.getString("numberPlate"), rs.getString("yearOfManufacture"), rs.getString("brand"), rs.getString("haveInsurance"), rs.getString("insuranceRegistStartDate"), rs.getString("havePositioningDevice"), rs.getString("backSenSor"));
					cars.add(car);
				}
				
			}

		} catch (SQLException e) {
			System.out.println("SQL: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		} finally {
			closeConnection(con);
		}
		return cars;
	}

	// public static void editKhachHang(KhachHang kh) {
	// Connection con = null;
	//
	// String sql = "UPDATE KhachHang SET HoTen = ?, Tuoi = ?, NgaySinh = ?,
	// NoiSinhSong = ?";
	// try {
	// con = getSQLServerConnection();
	// PreparedStatement ptmt = con.prepareStatement(sql);
	// ptmt.setString(1, kh.getHoTen());
	// ptmt.setString(2, kh.getTuoi());
	// ptmt.setString(3, kh.getNgaySinh());
	// ptmt.setString(4, kh.getNoiSinhSong());
	//
	// int rs = ptmt.executeUpdate();
	// if (rs > 0) {
	// System.out.println("OK");
	// } else {
	// System.out.println("Not good");
	// }
	//
	// } catch (SQLException e) {
	// System.out.println("SQL: " + e.getMessage());
	// } catch (Exception e) {
	// System.out.println("Exception: " + e.getMessage());
	// } finally {
	// closeConnection(con);
	// }
	// }

	public static ArrayList<String> getAttributesOfObject(Object obj) {
		// Get all attribute
		ArrayList<String> attributes = new ArrayList<>();

		for (Method m : obj.getClass().getMethods()) {
			if (m.getName().indexOf("get") == 0 && m.getName().indexOf("getClass") != 0) {
				attributes.add(m.getName().substring(3));
			}
		}
		// Sort attributes: SuperClass -> SubClass
		for (Method m : obj.getClass().getDeclaredMethods()) {
			if (m.getName().indexOf("get") == 0 && m.getName().indexOf("getClass") != 0) {
				if (attributes.contains(m.getName().substring(3)) == true) {
					attributes.remove(m.getName().substring(3));
					attributes.add(m.getName().substring(3));
				}
			}
		}

		return attributes;
	}

	// public static void delKhachHang(KhachHang kh) {
	// Connection con = null;
	//
	// String sql = "DELETE KhachHang WHERE HoTen = ? AND Tuoi = ? AND NgaySinh
	// = ? AND NoiSinhSong = ?";
	// try {
	// con = getSQLServerConnection();
	// PreparedStatement ptmt = con.prepareStatement(sql);
	// ptmt.setString(1, kh.getHoTen());
	// ptmt.setString(2, kh.getTuoi());
	// ptmt.setString(3, kh.getNgaySinh());
	// ptmt.setString(4, kh.getNoiSinhSong());
	//
	// int rs = ptmt.executeUpdate();
	// if (rs > 0) {
	// System.out.println("OK");
	// } else {
	// System.out.println("Not good");
	// }
	//
	// } catch (SQLException e) {
	// System.out.println("SQL: " + e.getMessage());
	// } catch (Exception e) {
	// System.out.println("Exception: " + e.getMessage());
	// } finally {
	// closeConnection(con);
	// }
	// }

	public static Hashtable<String, String> getValuesOfObject(Object obj) {
		Hashtable<String, String> table = new Hashtable<String, String>();
		ArrayList<String> args = new ArrayList<>();

		for (Method m : obj.getClass().getMethods()) {
			if (m.getName().indexOf("get") == 0 && m.getName().indexOf("getClass") != 0) {
				table.put(m.getName().substring(3), "");
			}
		}
		System.out.println(obj);
		return null;
	}

	// @SuppressWarnings("resource")
	// public static void dangKyBH(KhachHang kh, BaoHiem bh) {
	// Connection con = new Connection() {
	//
	// @Override
	// public <T> T unwrap(Class<T> iface) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public boolean isWrapperFor(Class<?> iface) throws SQLException {
	// // TODO Auto-generated method stub
	// return false;
	// }
	//
	// @Override
	// public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setTransactionIsolation(int level) throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setSchema(String schema) throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public Savepoint setSavepoint(String name) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public Savepoint setSavepoint() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public void setReadOnly(boolean readOnly) throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setNetworkTimeout(Executor executor, int milliseconds) throws
	// SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setHoldability(int holdability) throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setClientInfo(String name, String value) throws
	// SQLClientInfoException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setClientInfo(Properties properties) throws
	// SQLClientInfoException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setCatalog(String catalog) throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setAutoCommit(boolean autoCommit) throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void rollback(Savepoint savepoint) throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void rollback() throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void releaseSavepoint(Savepoint savepoint) throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public PreparedStatement prepareStatement(String sql, int resultSetType,
	// int resultSetConcurrency,
	// int resultSetHoldability) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public PreparedStatement prepareStatement(String sql, int resultSetType,
	// int resultSetConcurrency)
	// throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public PreparedStatement prepareStatement(String sql, String[]
	// columnNames) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public PreparedStatement prepareStatement(String sql, int[]
	// columnIndexes) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public PreparedStatement prepareStatement(String sql, int
	// autoGeneratedKeys) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public PreparedStatement prepareStatement(String sql) throws SQLException
	// {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public CallableStatement prepareCall(String sql, int resultSetType, int
	// resultSetConcurrency,
	// int resultSetHoldability) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public CallableStatement prepareCall(String sql, int resultSetType, int
	// resultSetConcurrency)
	// throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public CallableStatement prepareCall(String sql) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public String nativeSQL(String sql) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public boolean isValid(int timeout) throws SQLException {
	// // TODO Auto-generated method stub
	// return false;
	// }
	//
	// @Override
	// public boolean isReadOnly() throws SQLException {
	// // TODO Auto-generated method stub
	// return false;
	// }
	//
	// @Override
	// public boolean isClosed() throws SQLException {
	// // TODO Auto-generated method stub
	// return false;
	// }
	//
	// @Override
	// public SQLWarning getWarnings() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public Map<String, Class<?>> getTypeMap() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public int getTransactionIsolation() throws SQLException {
	// // TODO Auto-generated method stub
	// return 0;
	// }
	//
	// @Override
	// public String getSchema() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public int getNetworkTimeout() throws SQLException {
	// // TODO Auto-generated method stub
	// return 0;
	// }
	//
	// @Override
	// public DatabaseMetaData getMetaData() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public int getHoldability() throws SQLException {
	// // TODO Auto-generated method stub
	// return 0;
	// }
	//
	// @Override
	// public String getClientInfo(String name) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public Properties getClientInfo() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public String getCatalog() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public boolean getAutoCommit() throws SQLException {
	// // TODO Auto-generated method stub
	// return false;
	// }
	//
	// @Override
	// public Struct createStruct(String typeName, Object[] attributes) throws
	// SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public Statement createStatement(int resultSetType, int
	// resultSetConcurrency, int resultSetHoldability)
	// throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public Statement createStatement(int resultSetType, int
	// resultSetConcurrency) throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public Statement createStatement() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public SQLXML createSQLXML() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public NClob createNClob() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public Clob createClob() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public Blob createBlob() throws SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public Array createArrayOf(String typeName, Object[] elements) throws
	// SQLException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// @Override
	// public void commit() throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void close() throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void clearWarnings() throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void abort(Executor executor) throws SQLException {
	// // TODO Auto-generated method stub
	//
	// }
	// };
	// StringBuffer sql1 = new StringBuffer("INSERT INTO " +
	// bh.getClass().getSimpleName() + "(");
	// StringBuffer sql2 = new StringBuffer(" VALUES (");
	// ArrayList<String> list = getAttributesOfObject(bh);
	// int n = list.size();
	// for (int i = 0; i < n; i++) {
	// if (i == n - 1) {
	// sql1.append(list.get(i) + ")");
	// sql2.append("\'" + list.get(i) + "\')");
	//
	// } else {
	// sql1.append(list.get(i) + ",");
	// sql2.append("\'" + list.get(i) + "\'" + ",");
	// }
	// }
	//
	// String sql = sql1.toString() + sql2.toString();
	// System.out.println(sql);
	// try {
	// con.setAutoCommit(false);
	// con = getSQLServerConnection();
	// Statement stmt = con.createStatement();
	// int rs = stmt.executeUpdate(sql);
	// if (rs > 0) {
	// System.out.println("ok");
	// }
	//
	// } catch (ClassNotFoundException | SQLException e) {
	// try {
	// con.rollback();
	// } catch (SQLException e1) {
	// e1.printStackTrace();
	// }
	// System.out.println(e.getMessage());
	// } catch (Exception e) {
	// System.out.println(e.getMessage());
	// } finally {
	// try {
	// con.setAutoCommit(true);
	// } catch (SQLException e) {
	// // TODO Auto-generated catch block
	// System.out.println(e.getMessage());
	// }
	// closeConnection(con);
	// }
	// }

	public static void main(String[] args) {
		// KhachHang kh = new KhachHang();
		// kh.setHoTen("Nguyen Van B");
		// kh.setNgaySinh("12/12/2005");
		// kh.setTuoi("12");
		// kh.setNoiSinhSong("Da Nang 1");
		//
		//// delKhachHang(kh);
		// BaoHiemSinhKy bh = new BaoHiemSinhKy();
		// bh.setTenGoi("Bao hiem sinh ky");
		// bh.setNgayBatDau("1/1/2000");
		// bh.setNgayKetThuc("2/2/2000");
		// bh.setHinhThucDong("1 Lan");
		//
		//// dangKyBH(kh, bh);
		// getValuesOfObject(bh);
	}
}
