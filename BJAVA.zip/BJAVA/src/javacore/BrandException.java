package javacore;

public class BrandException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static boolean validate(String msg) {
		if (msg.equals("Hyundai")) {
			return true;
		}
		if (msg.equals("Toyota")) {
			return true;
		}
		if (msg.equals("Kia")) {
			return true;
		}
		if (msg.equals("Bmw")) {
			return true;
		}
		if (msg.equals("Audi")) {
			return true;
		}

		return false;
	}

	@Override
	public String getMessage() {
		return "Hang nay chua tung thay nhe !";
	}
}
