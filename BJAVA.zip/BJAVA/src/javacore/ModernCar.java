package javacore;

public class ModernCar extends Car {
	private String havePositioningDevice;
	private String backSenSor;

	/**
	 * 
	 */
	public ModernCar() {
		super();
	}

	/**
	 * @param numberPlate
	 * @param yearOfManufacture
	 * @param brand
	 * @param haveInsurance
	 * @param insuranceRegistStartDate
	 * @param havePositioningDevice
	 * @param backSenSor
	 */
	public ModernCar(String numberPlate, String yearOfManufacture, String brand, String haveInsurance,
			String insuranceRegistStartDate, String havePositioningDevice, String backSenSor) {
		super(numberPlate, yearOfManufacture, brand, haveInsurance, insuranceRegistStartDate);
		this.havePositioningDevice = havePositioningDevice;
		this.backSenSor = backSenSor;
	}

	/**
	 * @return the havePositioningDevice
	 */
	public String getHavePositioningDevice() {
		return havePositioningDevice;
	}

	/**
	 * @param havePositioningDevice
	 *            the havePositioningDevice to set
	 */
	public void setHavePositioningDevice(String havePositioningDevice) {
		this.havePositioningDevice = havePositioningDevice;
	}

	/**
	 * @return the backSenSor
	 */
	public String getBackSenSor() {
		return backSenSor;
	}

	/**
	 * @param backSenSor
	 *            the backSenSor to set
	 */
	public void setBackSenSor(String backSenSor) {
		this.backSenSor = backSenSor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javacore.Car#showMyInfo()
	 */
	@Override
	public void showMyInfo() {
		System.out.println("-----"+this.getClass().getSimpleName()+"-----");
		super.showMyInfo();
		System.out.println(toString());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return " ModernCar [havePositioningDevice=" + havePositioningDevice + ", backSenSor=" + backSenSor + "]";
	}

	/* (non-Javadoc)
	 * @see javacore.Car#nhap()
	 */
	@Override
	public void nhap(){
		super.nhap();
		System.out.print("Nhap co thiet bi dinh vi: ");
		this.havePositioningDevice = sc.nextLine();
		System.out.print("Nhap co cam biet lui: ");
		this.backSenSor = sc.nextLine();
		
	}

	@Override
	public int compareTo(Car c) {
		int car1 = Integer.valueOf(this.getYearOfManufacture());
		int car2 = Integer.valueOf(c.getYearOfManufacture());
		if(Integer.compare(car1, car2) != 0){
			return Integer.compare(car1, car2);
		}else{
			int bh1 = Integer.valueOf(this.getInsuranceRegistStartDate());
			int bh2 = Integer.valueOf(c.getInsuranceRegistStartDate());
			return Integer.compare(bh1, bh2);
		}
		
	}
	
}
